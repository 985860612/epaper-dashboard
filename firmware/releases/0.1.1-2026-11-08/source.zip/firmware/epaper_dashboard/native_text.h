#pragma once
#include <Adafruit_GFX.h>
#include <miniz.h>
#include "font_data.h"

// A shared 32KB page cache keeps all names usable without a large app partition.
inline uint8_t glyphCache[32768];
inline int cachedGlyphBlock = -1;

class NativeText {
  Adafruit_GFX* target = nullptr;
  int cursorX = 0, cursorY = 0;
  uint16_t color = 0;
  static uint32_t nextCode(const char*& p) {
    uint8_t c=static_cast<uint8_t>(*p++);
    if(c<128) return c;
    int n=c<0xe0 ? 1 : c<0xf0 ? 2 : 3;
    uint32_t value=c&((1u<<(6-n))-1);
    while(n-- && *p) value=(value<<6)|(static_cast<uint8_t>(*p++)&63);
    return value;
  }
  static int glyphIndex(uint32_t code) {
    int lo=0, hi=sizeof(GLYPH_CODES)/sizeof(GLYPH_CODES[0])-1;
    while(lo<=hi) { int mid=(lo+hi)/2; if(GLYPH_CODES[mid]==code) return mid; if(GLYPH_CODES[mid]<code) lo=mid+1; else hi=mid-1; }
    return -1;
  }
  static int advance(uint32_t c) { return c>=32 && c<127 ? ASCII_ADVANCE[c-32] : 17; }
public:
  void begin(Adafruit_GFX& d) { target=&d; }
  void setForegroundColor(uint16_t c) { color=c; }
  void setCursor(int x,int y) { cursorX=x; cursorY=y; }
  int getUTF8Width(const char* p) { int w=0; while(*p) w+=advance(nextCode(p)); return w; }
  void print(const String& text) {
    const char* p=text.c_str();
    while(*p) {
      uint32_t code=nextCode(p); int index=glyphIndex(code);
      if(index<0) index=glyphIndex('?');
      int block=index/1024;
      if(block!=cachedGlyphBlock) {
        size_t output=tinfl_decompress_mem_to_mem(glyphCache,sizeof(glyphCache),GLYPH_ZLIB+GLYPH_BLOCKS[block],
          GLYPH_BLOCKS[block+1]-GLYPH_BLOCKS[block],TINFL_FLAG_PARSE_ZLIB_HEADER|TINFL_FLAG_USING_NON_WRAPPING_OUTPUT_BUF);
        if(output==TINFL_DECOMPRESS_MEM_TO_MEM_FAILED) { cachedGlyphBlock=-1; cursorX+=advance(code); continue; }
        cachedGlyphBlock=block;
      }
      if(target) target->drawBitmap(cursorX,cursorY-15,glyphCache+(index%1024)*32,16,16,color);
      cursorX+=advance(code);
    }
  }
};
