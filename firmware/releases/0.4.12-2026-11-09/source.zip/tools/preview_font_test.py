# /// script
# dependencies = ["Pillow>=12,<13"]
# ///
"""Render the comparison page from firmware bitmaps; validate sample coverage and bounds."""
from pathlib import Path
import argparse
import json
import re
import zlib
from PIL import Image, ImageDraw

root = Path(__file__).resolve().parents[1]
p = argparse.ArgumentParser(description=__doc__)
p.add_argument('--output', type=Path, default=root / 'build/font-test-preview')
a = p.parse_args()
a.output.mkdir(parents=True, exist_ok=True)
sketch = root / 'firmware/epaper_dashboard'
styles = (sketch / 'generated_styles.h').read_text()
native = (sketch / 'font_data.h').read_text()
layout = (sketch / 'font_test_draw.h').read_text()

def array(source, name):
    body = re.search(r'\b'+name+r'\[\].*?\{(.*?)\};', source, re.S).group(1)
    return list(map(int, re.findall(r'-?\d+', body)))

def style(name):
    bits = bytes(array(styles, name+'Bits'))
    if name.upper()+'_RAW_BYTES' in styles:
        bits = zlib.decompress(bits)
    rows = re.search(r'\b'+name+r'Glyphs\[\].*?\{(.*?)\};', styles, re.S).group(1)
    glyphs = {g[0]: g[1:] for row in re.findall(r'\{([^{}]+)\}', rows)
              if (g := tuple(map(int, row.split(','))))}
    return bits, glyphs

codes = array(native, 'GLYPH_CODES')
advances = array(native, 'ASCII_ADVANCE')
blocks = array(native, 'GLYPH_BLOCKS')
packed = bytes(array(native, 'GLYPH_ZLIB'))
body = b''.join(zlib.decompress(packed[l:r]) for l, r in zip(blocks, blocks[1:]))
canvas = Image.new('RGB', (400, 300), 'white')
draw = ImageDraw.Draw(canvas)
red = '#b0162b'
bounds = []

def label(x, baseline, text):
    for c in text:
        assert ord(c) in codes, f'caption missing: {c}'
        i = codes.index(ord(c))
        mask = Image.frombytes('1', (16, 16), body[i*32:(i+1)*32])
        canvas.paste('black', (x, baseline-16), mask)
        x += advances[ord(c)-32] if 32 <= ord(c) < 127 else 16
    assert x <= 400

def width(text, font):
    return sum(font[1][ord(c)][3] for c in text)

def text(x, baseline, value, font, color):
    bits, glyphs = font
    for c in value:
        assert ord(c) in glyphs, f'sample missing: {c}'
        off, w, h, advance, dx, dy = glyphs[ord(c)]
        mask = Image.frombytes('1', (w, h), bits[off:off+((w+7)//8)*h])
        if box := mask.getbbox():
            region = (x+dx+box[0], baseline+dy+box[1], x+dx+box[2], baseline+dy+box[3])
            assert 0 <= region[0] < region[2] <= 400 and 0 <= region[1] < region[3] <= 300, region
            bounds.append(region)
        canvas.paste(color, (x+dx, baseline+dy), mask)
        x += advance

heading = re.search(r'FONT_TEST_HEADING="([^"]*)"', layout).group(1)
text(20, 29, heading, style('TestSelectedHan20'), 'black')
f = style('Card24')
text(382-width('12:34', f), 29, '12:34', f, 'black')
draw.line((18, 36, 381, 36), fill='black')
names = re.search(r'faces\[\]=\{(.*?)\}', layout).group(1).replace('&', '').split(',')
titles = re.findall(r'"([^"]*)"', re.search(r'titles\[\]=\{(.*?)\}', layout).group(1))
first_y = int(re.search(r'FONT_TEST_FIRST_Y=(\d+)', layout).group(1))
row_height = int(re.search(r'FONT_TEST_ROW_HEIGHT=(\d+)', layout).group(1))
letters = re.search(r'FONT_TEST_LETTERS="([^"]*)"', layout).group(1)
digits = re.search(r'FONT_TEST_DIGITS="([^"]*)"', layout).group(1)
for row, (name, title) in enumerate(zip(names, titles)):
    y = first_y+row*row_height
    label(20, y, title)
    f = style(name)
    assert 20+width(letters, f) < 382-width(digits, f), name
    text(20, y+22, letters, f, 'black')
    text(382-width(digits, f), y+22, digits, f, red)

draw.line((18,236,381,236),fill='black')
label(20,254,'Regular 40px');label(218,254,'Bold 40px')
text(20,296,'29.78',style('TestArialRegular40'),'black')
text(218,296,'29.78',style('TestArialBold40'),'black')
canvas.save(a.output / 'font-test-400x300.png')
canvas.resize((1200, 900), Image.Resampling.NEAREST).save(a.output / 'font-test-1200x900.png')
report = {'fontPx':[18,18,24,24], 'largeFontPx':40, 'largeSamplesSameInk':'black', 'largeSample':'29.78 placeholder', 'rows':len(names), 'fonts':names, 'selectedChinese':'FangZhengJingXiHei-1.ttf',
          'sampleGlyphsCovered':True, 'sampleBoundsInsidePanel':True,
          'sampleColumnsSeparated':True, 'previewTime':'12:34 placeholder',
          'digitAdvancePixels':{name:[style(name)[1][ord(c)][3] for c in digits] for name in names},
          'userFontMissing':{
              file.stem: json.loads(file.read_text())['missingComparisonCharacters']
              for file in sorted((root/'assets/fonts').glob('*.metadata.json'))}}
(a.output / 'layout-check.json').write_text(json.dumps(report, ensure_ascii=False, indent=2)+'\n')
print(json.dumps(report, ensure_ascii=False))
