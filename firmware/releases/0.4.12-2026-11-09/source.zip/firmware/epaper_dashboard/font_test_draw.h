#pragma once
constexpr int FONT_TEST_FIRST_Y=56;
constexpr int FONT_TEST_ROW_HEIGHT=48;
constexpr const char* FONT_TEST_LETTERS="AaGgIl .:%";
constexpr const char* FONT_TEST_DIGITS="0123456789";
constexpr const char* FONT_TEST_HEADING="晶细黑 · Arial字重";
static void drawFontTest(const tm& now) {
  styleText(*painter,20,29,FONT_TEST_HEADING,TestSelectedHan20,GxEPD_BLACK);
  cardNumber(382,29,cardTime(now),Card24,GxEPD_BLACK,true);
  painter->drawFastHLine(18,36,364,GxEPD_BLACK);
  const StyleFont* faces[]={&TestArialRegular18,&TestArialBold18,&TestArialRegular24,&TestArialBold24};
  const char* titles[]={"Arial Regular 18px","Arial Bold 18px","Arial Regular 24px","Arial Bold 24px"};
  for(unsigned row=0;row<sizeof(faces)/sizeof(faces[0]);++row) {
    int y=FONT_TEST_FIRST_Y+row*FONT_TEST_ROW_HEIGHT;label(20,y,titles[row]);
    const auto& face=*faces[row];
    styleText(*painter,20,y+22,FONT_TEST_LETTERS,face,GxEPD_BLACK);
    styleText(*painter,382-styleWidth(FONT_TEST_DIGITS,face),y+22,FONT_TEST_DIGITS,face,GxEPD_RED);
  }
  painter->drawFastHLine(18,236,364,GxEPD_BLACK);
  label(20,254,"Regular 40px");label(218,254,"Bold 40px");
  styleText(*painter,20,296,"29.78",TestArialRegular40,GxEPD_BLACK);
  styleText(*painter,218,296,"29.78",TestArialBold40,GxEPD_BLACK);
}
