#pragma once
#include <Arduino.h>
#include <ArduinoJson.h>
#include <WebServer.h>
#include <time.h>
#include "market_clock.h"

constexpr const char* VERSION = "epaper-dashboard-0.1.2";
constexpr int MAX_STOCKS = 8, MAX_POINTS = 245;

struct Settings {
  String ssid, wifiPassword, apiHost, apiKey, adminPassword;
  String location = "101010400", city = "北京顺义", view = "auto";
  String stocks[MAX_STOCKS] = {"sh600900"};
  int stockCount = 1, refreshSeconds = 120, rotationSeconds = 300;
  int calendarYear = 2026;
  String holidays = "20260101,20260102,20260216,20260217,20260218,20260219,20260220,20260223,20260406,20260501,20260504,20260505,20260619,20260925,20261001,20261002,20261005,20261006,20261007";
};

struct Weather {
  bool valid = false, dailyValid = false;
  float temp = 0, low = 0, high = 0;
  int icon = 100;
  String text, observedAt, location;
  time_t receivedAt = 0;
};

struct Point { int offset; float price, average; };
struct Stock {
  bool valid = false;
  String symbol, name, stamp, minuteDate;
  float price = 0, previous = 0, change = 0, percent = 0;
  time_t receivedAt = 0;
  Point points[MAX_POINTS];
  int count = 0;
};

extern Settings cfg;
extern Weather weather;
extern Stock stock;
extern WebServer server;
extern bool needRefresh, needFetch, needReconnect;
extern bool apActive, rendering;
extern int activeStock;
extern String weatherError, stockError, displayError;
extern uint32_t lastRefreshMs;

bool clockReady();
Phase currentPhase();
String dateCompact();
const char* phaseCode(Phase p);
void loadSettings();
bool applySettings(JsonObjectConst input, String& error, bool serial = false);
void settingsJson(JsonDocument& doc, bool secrets = false);
void loadWeatherCache();
void saveWeatherCache();
bool fetchWeather(String& error);
bool fetchStock(const String& symbol, String& error);
bool lookupCities(const String& query, JsonDocument& doc, String& error);
void setupWeb();
void serviceWeb();
void initScreen();
void refreshScreen();
