#pragma once
static void drawFontTest(const tm& now) {
  label(20,27,"字体对照 20px");
  cardNumber(382,29,cardTime(now),Card24,GxEPD_BLACK,true);
  painter->drawFastHLine(18,36,364,GxEPD_BLACK);
  const StyleFont* faces[]={&CardText20,&TestArial20,&TestSemi20,&TestRou20,&TestNoto20};
  const char* titles[]={"当前 SFMono / 苹方中等","A Arial Bold / 苹方中等","B Arial Bold / 苹方中黑","C 源柔黑 Medium (缺顺义)","D Noto Sans CJK Regular"};
  for(int row=0;row<5;++row) {
    int y=56+row*48;label(20,y,titles[row]);
    const auto& face=*faces[row];
    styleText(*painter,20,y+25,"北京 星期一",face,GxEPD_BLACK);
    const String digits="0123456789";
    styleText(*painter,382-styleWidth(digits,face),y+25,digits,face,GxEPD_RED);
    painter->drawFastHLine(18,y+30,364,GxEPD_BLACK);
  }
}
