# 墨水屏字体对照

0.4.9新增临时字体对照页。五组中文和数字均按20px生成1-bit字模，中文黑色、数字红色；右上时间仍是用户喜欢的Arial Bold 24px。未缩放、未网点化，不把显示颜色差别解释为字重差别。截图预览为实际字模的最近邻放大，预览时间12:34是占位值，设备使用当前北京时间。

| 屏幕标签 | 中文 | 数字 |
| --- | --- | --- |
| 当前 | 苹方SC Medium | SF Mono Medium |
| A | 苹方SC Medium | Arial Bold |
| B | 苹方SC Semibold | Arial Bold |
| C | Gen Jyuu Gothic Medium（源柔黑） | 同左 |
| D | Noto Sans CJK Regular | 同左 |

C来自用户的SiYuanRouHei-Medium.zip。字体自身缺“顺、义”，测试统一使用所有字体都有的“北京 星期一”及0123456789；缺字已在C行标注，没有偷偷换字体补齐。D来自用户提供的NotoSansCJK-Regular-1.otf，包含“顺、义”。原字体、SHA-256和内嵌版权信息保存在assets/fonts/对应metadata.json；C按字体声明保留OFL1.1，D这份旧字体声明的是Apache2.0，分别附许可证。系统字体文件不随项目分发。

短按BOOT开启网页配置窗口，在“省电运行”中点“字体对照页”；显示后按钮变成“返回正常显示”。对照模式仅在RAM中保持，不写持久配置、不进入五张卡片轮播；重启即回到原页面选择。进入测试期间暂停交易页优先和轮播，退出后恢复原规则。顶部时间保留分钟局刷，其余样张保持；仍按现有策略轻睡眠。串口调试命令为JSON行：command=font_test，enabled=true或false。

从源码重建：uv run tools/build_fonts.py；预览和覆盖/边界检查：uv run tools/preview_font_test.py。构建仍用tools/build_firmware.py，保持原分区、NVS和波形。已生成的字模可直接编译，不需要另装字体。

[400×300实际字模预览](../assets/font-comparison/font-test-400x300.png) · [3倍最近邻放大](../assets/font-comparison/font-test-1200x900.png)。视觉效果仍待用户实屏确认。
