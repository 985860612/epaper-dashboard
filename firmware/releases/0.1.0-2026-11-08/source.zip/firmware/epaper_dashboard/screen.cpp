#include "app.h"
#include <SPI.h>
#include <WiFi.h>
#include <GxEPD2_3C.h>
#include "native_text.h"
#include <Fonts/FreeSansBold9pt7b.h>
#include <Fonts/FreeSansBold12pt7b.h>
#include <Fonts/FreeSansBold18pt7b.h>
#include <Fonts/FreeSansBold24pt7b.h>

class HinkPanel : public GxEPD2_420c_GDEY042Z98 {
public:
  using GxEPD2_420c_GDEY042Z98::GxEPD2_420c_GDEY042Z98;
  void allowLongRefresh() { _busy_timeout = 90000000; }
};
static GxEPD2_3C<HinkPanel, 32> display(HinkPanel(10, 13, 7, 4));
static NativeText font;
static uint32_t busyStart, lastBusyLog;

static void label(int x, int y, const String& text, uint16_t color = GxEPD_BLACK, bool right = false) {
  font.setForegroundColor(color);
  if (right) x -= font.getUTF8Width(text.c_str());
  font.setCursor(x, y); font.print(text);
}

static void latin(int x, int y, const String& text, const GFXfont* face, uint16_t color = GxEPD_BLACK, bool right = false, int size = 1) {
  display.setFont(face); display.setTextSize(size); display.setTextColor(color);
  if (right) { int16_t a, b; uint16_t w, h; display.getTextBounds(text, 0, y, &a, &b, &w, &h); x -= w + a; }
  display.setCursor(x, y); display.print(text); display.setTextSize(1);
}

static String clipped(const String& input, int count) {
  int characters = 0, end = 0;
  for (unsigned int i = 0; i < input.length(); ++i) {
    if ((static_cast<uint8_t>(input[i]) & 0xc0) != 0x80) {
      if (characters++ == count) break;
    }
    end = i + 1;
  }
  return input.substring(0, end);
}

static void bigName(const String& text) {
  if (clipped(text, 5) != text) { label(20, 73, clipped(text, 13)); return; }
  GFXcanvas1 canvas(100, 20);
  if (!canvas.getBuffer()) { label(20, 73, text); return; }
  NativeText local;
  local.begin(canvas);
  local.setForegroundColor(1); local.setCursor(0, 16); local.print(text);
  for (int y = 0; y < 20; ++y) for (int x = 0; x < 100; ++x)
    if (canvas.getPixel(x, y)) display.fillRect(20 + x*2, 41 + y*2, 2, 2, GxEPD_BLACK);
}

static String phaseLabel(Phase p) {
  switch (p) {
    case Phase::Auction: return "集合竞价";
    case Phase::Opening: return "待开盘";
    case Phase::Trading: return "交易中";
    case Phase::Closing: return "收盘竞价";
    case Phase::Unknown: return "日历待更新";
    default: return "已休市";
  }
}

static void weatherIcon(int code) {
  if (code < 104) {
    display.drawCircle(46, 213, 12, GxEPD_BLACK);
    for (int i = 0; i < 8; ++i) {
      float a = i * PI / 4;
      display.drawLine(46+17*cos(a), 213+17*sin(a), 46+22*cos(a), 213+22*sin(a), GxEPD_BLACK);
    }
  }
  if (code != 100 && code != 150) {
    display.fillRect(29, 222, 40, 20, GxEPD_WHITE);
    display.drawCircle(40, 228, 12, GxEPD_BLACK);
    display.drawCircle(54, 221, 14, GxEPD_BLACK);
    display.drawCircle(67, 231, 10, GxEPD_BLACK);
    display.fillRect(33, 228, 40, 12, GxEPD_WHITE);
    display.drawFastHLine(34, 241, 34, GxEPD_BLACK);
    if (code >= 300 && code < 500) for (int x = 38; x <= 66; x += 12) display.drawLine(x, 247, x-3, 253, GxEPD_BLACK);
  }
}

static void drawClock(const tm& now, bool valid, const Weather& w, const String& city, Phase phase) {
  char date[40], time[8];
  if (valid) { snprintf(date, sizeof(date), "%04d.%02d.%02d", now.tm_year+1900, now.tm_mon+1, now.tm_mday); snprintf(time, sizeof(time), "%02d:%02d", now.tm_hour, now.tm_min); }
  else { strcpy(date, "等待阿里云校时"); strcpy(time, "--:--"); }
  label(20, 30, date);
  if (valid) { const char* days[] = {"周日", "周一", "周二", "周三", "周四", "周五", "周六"}; label(380, 30, days[now.tm_wday], GxEPD_BLACK, true); }
  display.setFont(&FreeSansBold24pt7b); display.setTextSize(2);
  int16_t x, y; uint16_t width, height;
  display.getTextBounds(time, 0, 130, &x, &y, &width, &height);
  latin((400-width)/2-x, 137, time, &FreeSansBold24pt7b, GxEPD_BLACK, false, 2);
  display.drawFastHLine(20, 169, 360, GxEPD_BLACK);
  weatherIcon(w.valid ? w.icon : 104);
  latin(88, 237, w.valid ? String(w.temp, 0) : "--", &FreeSansBold24pt7b);
  display.drawCircle(173, 207, 3, GxEPD_BLACK);
  label(220, 215, w.valid ? clipped(w.text, 9) : "天气待更新");
  label(220, 242, clipped(city, 9));
  String footer = "和风天气";
  if (!w.valid) footer += " · 未获取";
  else if (!weatherError.isEmpty() || ::time(nullptr)-w.receivedAt > 3600) footer += " · 缓存";
  label(20, 286, footer);
  if (w.dailyValid) label(380, 286, String(w.low,0)+" / "+String(w.high,0)+" C", GxEPD_BLACK, true);
  if (phase == Phase::Unknown) label(20, 190, "请更新交易日历", GxEPD_RED);
}

static void drawStock(const tm& now, const Stock& s, const Weather& w, const String& city,
                      Phase phase, int index, int total, bool stale) {
  char date[24]; snprintf(date, sizeof(date), "%02d.%02d  %02d:%02d", now.tm_mon+1, now.tm_mday, now.tm_hour, now.tm_min);
  label(20, 25, date);
  label(380, 25, clipped(city, 4)+" "+(w.valid ? String(w.temp,0) : "--")+" C", GxEPD_BLACK, true);
  display.drawFastHLine(20, 38, 360, GxEPD_BLACK);
  bigName(s.valid ? s.name : cfg.stocks[index]);
  char todayBuffer[9]; strftime(todayBuffer,sizeof(todayBuffer),"%Y%m%d",&now);
  String today = todayBuffer;
  bool historical = s.valid && s.stamp.substring(0,8) != today;
  label(380, 73, historical ? "历史行情" : stale ? "数据延迟" : phaseLabel(phase), GxEPD_RED, true);
  uint16_t color = s.change > 0 ? GxEPD_RED : GxEPD_BLACK;
  latin(18, 113, s.valid ? String(s.price,2) : "--.--", &FreeSansBold24pt7b, color);
  String delta = s.valid ? (s.change > 0 ? "+" : "")+String(s.change,2)+"  "+(s.percent > 0 ? "+" : "")+String(s.percent,2)+"%" : "--  --%";
  latin(380, 109, delta, &FreeSansBold12pt7b, color, true);
  bool auction = (phase == Phase::Auction || phase == Phase::Opening) && !historical;
  bool hasCurve = s.valid && s.count > 0 && !auction;
  if (hasCurve) {
    const int left = 47, right = 337, top = 151, bottom = 237;
    float lo = s.previous, hi = s.previous;
    for (int i = 0; i < s.count; ++i) {
      lo = min(lo, s.points[i].price); hi = max(hi, s.points[i].price);
      if (isfinite(s.points[i].average)) { lo = min(lo, s.points[i].average); hi = max(hi, s.points[i].average); }
    }
    float margin = max((hi-lo)*0.1f, s.previous*0.002f);
    lo -= margin; hi += margin;
    auto py = [&](float v) { return bottom-static_cast<int>(lround((v-lo)/(hi-lo)*(bottom-top))); };
    for (int xx = left; xx <= right; xx += 8) display.drawFastHLine(xx, py(s.previous), min(4, right-xx+1), GxEPD_BLACK);
    for (int i = 1; i < s.count; ++i) {
      int x0 = left+s.points[i-1].offset*(right-left)/240, x1 = left+s.points[i].offset*(right-left)/240;
      display.drawLine(x0,py(s.points[i-1].price),x1,py(s.points[i].price),GxEPD_BLACK);
      if (isfinite(s.points[i-1].average) && isfinite(s.points[i].average)) display.drawLine(x0,py(s.points[i-1].average),x1,py(s.points[i].average),GxEPD_RED);
    }
    const Point& last = s.points[s.count-1];
    label(20, 140, isfinite(last.average) ? "均价 "+String(last.average,2) : "均价暂无", GxEPD_RED);
    label(380, 140, "价格线 / 均价线", GxEPD_BLACK, true);
    latin(43, top+5, String(hi,2), &FreeSansBold9pt7b, GxEPD_BLACK, true);
    latin(43, bottom+4, String(lo,2), &FreeSansBold9pt7b, GxEPD_BLACK, true);
    latin(395, top+5, String((hi/s.previous-1)*100,2)+"%", &FreeSansBold9pt7b, GxEPD_RED, true);
    latin(395, bottom+4, String((lo/s.previous-1)*100,2)+"%", &FreeSansBold9pt7b, GxEPD_BLACK, true);
    label(47, 260, "09:30"); label(192, 260, "11:30/13:00", GxEPD_BLACK, true); label(337, 260, "15:00", GxEPD_BLACK, true);
  } else {
    label(30, 184, auction ? "集合竞价 · 等待正式开盘" : "等待有效分时数据");
    label(30, 215, stockError.length() ? clipped(stockError,20) : "分时线从09:30开始绘制");
  }
  display.drawFastHLine(20, 270, 360, GxEPD_BLACK);
  String stamp = s.valid ? s.stamp.substring(4,6)+"-"+s.stamp.substring(6,8)+" "+s.stamp.substring(8,10)+":"+s.stamp.substring(10,12) : "--:--";
  label(20, 290, "行情 "+stamp);
  label(380, 290, String(index+1)+"/"+String(total), GxEPD_BLACK, true);
}

static void busyCallback(const void*) {
  serviceWeb();
  if (millis()-lastBusyLog > 5000) {
    lastBusyLog = millis();
    Serial.printf("DISPLAY_BUSY elapsed_ms=%lu BUSY=%d\n", static_cast<unsigned long>(millis()-busyStart), digitalRead(4));
  }
  delay(1);
}

void initScreen() {
  SPI.begin(12, -1, 11, 10);
  display.epd2.selectSPI(SPI, SPISettings(4000000, MSBFIRST, SPI_MODE0));
  display.epd2.allowLongRefresh(); display.epd2.setBusyCallback(busyCallback);
  display.init(115200);
  display.setRotation(0); display.epd2.selectFastFullUpdate(false);
  font.begin(display);
}

void refreshScreen() {
  Stock snapshot = stock; Weather w = weather; String city = cfg.city;
  tm now{}; time_t epoch = time(nullptr); localtime_r(&epoch, &now);
  bool valid = clockReady(), online = WiFi.status() == WL_CONNECTED;
  Phase phase = currentPhase();
  bool stocks = cfg.view == "stock" || (cfg.view == "auto" && stockPage(phase));
  bool stale = !stockError.isEmpty() || (snapshot.valid && time(nullptr)-snapshot.receivedAt > cfg.refreshSeconds*2);
  int index = activeStock, total = cfg.stockCount;
  rendering = true; needRefresh = false;
  busyStart = lastBusyLog = millis();
  display.setFullWindow(); display.firstPage();
  do {
    display.fillScreen(GxEPD_WHITE);
    if (!online && apActive) {
      label(20, 45, "墨水屏联网设置");
      label(20, 95, "请连接设备热点后打开");
      label(20, 125, "http://192.168.4.1");
      label(20, 165, "热点: EPaper-"+String(static_cast<uint32_t>(ESP.getEfuseMac()),HEX));
      label(20, 195, "密码: "+cfg.adminPassword);
      label(20, 225, "网页用户: admin");
    } else if (stocks && valid) drawStock(now,snapshot,w,city,phase,index,total,stale);
    else drawClock(now,valid,w,city,phase);
  } while (display.nextPage());
  if (digitalRead(4) == HIGH) displayError = "BUSY超时，请检查屏幕";
  else { displayError = ""; display.hibernate(); }
  Serial.printf("DISPLAY_DONE elapsed_ms=%lu BUSY=%d free_heap=%u\n",static_cast<unsigned long>(millis()-busyStart),digitalRead(4),ESP.getFreeHeap());
  lastRefreshMs = millis(); rendering = false;
}
