#pragma once
constexpr int FONT_TEST_FIRST_Y=56;
constexpr int FONT_TEST_ROW_HEIGHT=48;
constexpr const char* FONT_TEST_LETTERS="AaGgIl .:%";
constexpr const char* FONT_TEST_DIGITS="0123456789";
constexpr const char* FONT_TEST_HEADING="晶细黑 · 英数候选";
static void drawFontTest(const tm& now) {
  styleText(*painter,20,29,FONT_TEST_HEADING,TestSelectedHan20,GxEPD_BLACK);
  cardNumber(382,29,cardTime(now),Card24,GxEPD_BLACK,true);
  painter->drawFastHLine(18,36,364,GxEPD_BLACK);
  const StyleFont* faces[]={&TestArial24,&TestDIN24,&TestHelvetica24,&TestAvenir24,&TestSFMono24};
  const char* titles[]={"1 Arial Bold","2 DIN Alternate Bold","3 Helvetica Neue Medium","4 Avenir Next Demi Bold","5 SF Mono Medium"};
  for(unsigned row=0;row<sizeof(faces)/sizeof(faces[0]);++row) {
    int y=FONT_TEST_FIRST_Y+row*FONT_TEST_ROW_HEIGHT;label(20,y,titles[row]);
    const auto& face=*faces[row];
    styleText(*painter,20,y+26,FONT_TEST_LETTERS,face,GxEPD_BLACK);
    styleText(*painter,382-styleWidth(FONT_TEST_DIGITS,face),y+26,FONT_TEST_DIGITS,face,GxEPD_RED);
  }
}
