const fs = require('node:fs');
const path = require('node:path');
const assert = require('node:assert/strict');
const page = fs.readFileSync(path.join(__dirname, '../firmware/epaper_dashboard/web_page.h'), 'utf8');
const drawSource = page.split('\n').find(line => line.startsWith('function draw(s)'));
function render(points) {
  const calls=[];
  const context = Object.fromEntries(['clearRect','setLineDash','beginPath','moveTo','lineTo'].map(name=>[name,(...args)=>calls.push([name,...args])]));
  context.stroke=function(){calls.push(['stroke',this.strokeStyle]);};
  const draw = new Function('$',drawSource+'; return draw;')(()=>({width:760,height:160,getContext:()=>context}));
  draw({previous:29.91,points});return calls;
}
const points=[[0,29.55,29.60],[120,29.70,29.65],[240,29.83,29.71]];
const original=render(points);
assert.deepEqual(original,render(points.map(([t,p])=>[t,p,9999])));
assert.deepEqual(original.filter(c=>c[0]==='stroke').map(c=>c[1]),['#111','#b0162b']);
new Function(page.match(/<script>([\s\S]*?)<\/script>/)[1]);
console.log('PASS: embedded web JavaScript syntax, red price curve, no average influence on line or range');
