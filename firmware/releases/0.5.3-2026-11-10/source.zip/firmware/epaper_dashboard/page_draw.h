#pragma once
static void type(int x,int y,const String& value,TextRole role=TextRole::Body,uint16_t color=GxEPD_BLACK,TextAlign align=TextAlign::Left) {drawText(*painter,x,y,value,role,color,align);}
static void label(int x,int y,const String& value,uint16_t color=GxEPD_BLACK,bool right=false) {type(x,y,value,TextRole::Body,color,right?TextAlign::Right:TextAlign::Left);}

static String phaseLabel(Phase p) {
  switch (p) {
    case Phase::Auction: return "集合竞价";
    case Phase::Opening: return "待开盘";
    case Phase::Trading: return "交易中";
    case Phase::Closing: return "收盘竞价";
    case Phase::Unknown: return "日历待更新";
    default: return "已休市";
  }
}

static void drawClock(const tm& now,bool valid,const Weather& w,const String& city,Phase phase);
static void drawStock(const tm& now,const Stock& s,const Weather& w,const String& city,Phase phase,int index,bool stale);

#include "cards_draw.h"
#include "font_test_draw.h"

static void drawClock(const tm& now,bool valid,const Weather&,const String&,Phase phase) {
  cardHeader(valid?cardDate(now):"等待阿里云校时",valid?String(CARD_WEEKDAYS[now.tm_wday]):String(""));
  type(200,177,valid?cardTime(now):String("--:--"),TextRole::Clock,GxEPD_BLACK,TextAlign::Center);cardRule(208);
  cardCloud(20,232);type(82,274,weather.valid?String(weather.temp,0):String("--"),TextRole::Value);
  type(380,243,fitText(weatherDescription(),160),TextRole::Body,GxEPD_BLACK,TextAlign::Right);type(380,277,fitText(cfg.city,180),TextRole::Body,GxEPD_BLACK,TextAlign::Right);
  if(valid && phase==Phase::Unknown)type(20,76,"请更新交易日历",TextRole::Dense,GxEPD_RED);
}
static String axisNumber(float value,int width,bool percent=false) {
  int decimals=percent?2:(fabs(value)>=1000?0:2);String s;
  do {s=String(value,decimals)+(percent?"%":"");if(textWidth(s,TextRole::Axis)<=width)return s;}while(--decimals>=0);
  float unit=fabs(value)>=1000000?1000000:1000;return String(value/unit,1)+(unit==1000000?"M":"k")+(percent?"%":"");
}
static void stockSegment(int x0,int y0,float p0,int x1,int y1,float p1,float opening,int openingY) {
  uint16_t c0=!renderBw && p0>opening?GxEPD_RED:GxEPD_BLACK;
  uint16_t c1=!renderBw && p1>opening?GxEPD_RED:GxEPD_BLACK;
  if(c0==c1) {painter->drawLine(x0,y0,x1,y1,c0);return;}
  int cross=x0+static_cast<int>(lround((opening-p0)/(p1-p0)*(x1-x0)));
  painter->drawLine(x0,y0,cross,openingY,c0);
  painter->drawLine(cross,openingY,x1,y1,c1);
  painter->drawPixel(cross,openingY,GxEPD_BLACK);
}
static void drawStock(const tm& now,const Stock& s,const Weather& w,const String& city,Phase phase,int index,bool stale) {
  char date[24];snprintf(date,sizeof(date),"%02d.%02d  %02d:%02d",now.tm_mon+1,now.tm_mday,now.tm_hour,now.tm_min);
  type(20,29,date);String temp=w.valid?String(w.temp,0)+"°C":"--";
  type(380,29,fitText(city,148-textWidth(temp))+" "+temp,TextRole::Body,GxEPD_BLACK,TextAlign::Right);cardRule(42);
  bool historical=s.valid && s.stamp.substring(0,8)!=dateCompact();
  String name=fitText(s.valid?s.name:cfg.stocks[index],historical?188:250,TextRole::StockName);type(20,77,name,TextRole::StockName);
  if(historical && s.minuteDate.length()==8)type(28+textWidth(name,TextRole::StockName),77,s.minuteDate.substring(4,6)+"."+s.minuteDate.substring(6,8),TextRole::Dense);
  String state=historical?"历史行情":stale?"数据延迟":phaseLabel(phase);
  type(380,73,state,TextRole::Body,GxEPD_BLACK,TextAlign::Right);
  float change=s.price-s.previous,percent=s.previous>0?change/s.previous*100:0;uint16_t ink=!renderBw && change>0?GxEPD_RED:GxEPD_BLACK;
  type(20,124,s.valid?String(s.price,2):"--.--",TextRole::Price,renderBw?GxEPD_BLACK:GxEPD_RED);
  type(380,100,s.valid?(change>0?"+":"")+String(change,2):"--",TextRole::Body,ink,TextAlign::Right);
  type(380,125,s.valid?(percent>0?"+":"")+String(percent,2)+"%":"--%",TextRole::Body,ink,TextAlign::Right);
  bool auction=(phase==Phase::Auction || phase==Phase::Opening) && !historical;
  if(s.valid && s.count>0 && s.open>0 && !auction) {
    constexpr int left=20,right=340,top=132,bottom=296;float lo=s.previous,hi=s.previous;
    for(int i=0;i<s.count;++i) {lo=min(lo,s.points[i].price);hi=max(hi,s.points[i].price);}
    float margin=hi>lo?(hi-lo)*.03f:max(.01f,s.previous*.0005f);lo-=margin;hi+=margin;
    auto py=[&](float value) {return bottom-static_cast<int>(lround((value-lo)/(hi-lo)*(bottom-top)));};
    for(int x=left;x<=right;x+=8)painter->drawFastHLine(x,py(s.previous),min(4,right-x+1),GxEPD_BLACK);
    for(int i=1;i<s.count;++i) {
      int x0=left+s.points[i-1].offset*(right-left)/240,x1=left+s.points[i].offset*(right-left)/240;
      stockSegment(x0,py(s.points[i-1].price),s.points[i-1].price,x1,py(s.points[i].price),s.points[i].price,s.open,py(s.open));
    }
    type(396,top+12,axisNumber(hi,50),TextRole::Axis,GxEPD_BLACK,TextAlign::Right);
    type(396,bottom,axisNumber(lo,50),TextRole::Axis,GxEPD_BLACK,TextAlign::Right);
  } else {type(30,184,fitText(auction?"集合竞价·等待正式开盘":"等待有效分时数据",340));type(30,215,fitText(stockError.length()?stockError:"分时线从09:30开始绘制",340),TextRole::Dense);}
}

