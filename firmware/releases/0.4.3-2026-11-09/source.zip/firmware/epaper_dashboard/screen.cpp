#include "app.h"
#include <SPI.h>
#include <WiFi.h>
#include <GxEPD2_3C.h>
#include "native_text.h"
#include "styled_text.h"
#include "frame_canvas.h"
#include "red_waveform.h"
#include "red_transition.h"

// Adapted from HalfSweetStudio/EPaperDrive (AGPL-3.0):
// WAVEFORM_SETTING_LUT.h, LUTDefault_part_GDEY042Z98.
// https://github.com/HalfSweetStudio/EPaperDrive
// A register readback established a 227-byte waveform + 6 parameter layout.
// Only the volatile main waveform is copied; the panel-native voltage/end
// parameters stay unchanged. The upstream command byte is sent separately.
static const uint8_t ssd1619PartialLut[] = {
  0x01,0x19,0x00,0x00,0x00,0x01,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,
  0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,
  0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,
  0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,
  0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,
  0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,
  0x01,0x5e,0x00,0x00,0x00,0x01,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,
  0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,
  0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,
  0x01,0x9e,0x00,0x00,0x00,0x01,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,
  0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,
  0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,
  0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,
  0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,
  0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,
  0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,
  0x02,0x00,0x00,
 };
static_assert(sizeof(ssd1619PartialLut)==227,"Long-format LUT must contain 227 bytes");

class HinkPanel : public GxEPD2_420c_GDEY042Z98 {
public:
  using GxEPD2_420c_GDEY042Z98::GxEPD2_420c_GDEY042Z98;
  void allowLongRefresh() { _busy_timeout = 90000000; }
  void partialTimeout() { _busy_timeout = 8000000; }
  void normalGate() {
    _writeCommand(0x01);_writeData(0x2b);_writeData(0x01);_writeData(0x00);
    _writeCommand(0x3c);_writeData(0x05);
  }
  void restoreColorRegisters() { _init_display_done=false; }
  void readRegister(uint8_t command,uint8_t* bytes,size_t count) {
    // SSD1619 reads on bidirectional SDA. Release hardware SPI before changing
    // MOSI to input, then restore the established SPI pins/settings afterward.
    SPI.end();
    pinMode(12,OUTPUT);digitalWrite(12,LOW);
    pinMode(11,OUTPUT);digitalWrite(13,LOW);digitalWrite(10,LOW);
    for(int bit=7;bit>=0;--bit) {
      digitalWrite(11,(command>>bit)&1);delayMicroseconds(2);
      digitalWrite(12,HIGH);delayMicroseconds(2);digitalWrite(12,LOW);
    }
    digitalWrite(13,HIGH);pinMode(11,INPUT_PULLUP);
    for(size_t i=0;i<count;++i) {
      bytes[i]=0;
      for(int bit=0;bit<8;++bit) {
        delayMicroseconds(2);digitalWrite(12,HIGH);delayMicroseconds(2);
        bytes[i]=static_cast<uint8_t>((bytes[i]<<1)|(digitalRead(11)?1:0));
        digitalWrite(12,LOW);
      }
    }
    digitalWrite(10,HIGH);
    SPI.begin(12,-1,11,10);
    selectSPI(SPI,SPISettings(4000000,MSBFIRST,SPI_MODE0));
  }
  uint8_t nativeRed[233]{}, redLut[227]{};
  NativeControlInfo redInfo;
  bool cacheRedWaveform() {
    uint8_t second[233];
    readRegister(0x33,nativeRed,233);readRegister(0x33,second,233);
    redPartialReady=memcmp(nativeRed,second,233)==0 && makeNativeHold(nativeRed,233,redLut,227,redInfo);
    Serial.printf("RED_PROFILE ready=%d nominal_ms=%u tail=%02X\n",redPartialReady,redInfo.nominalMilliseconds,nativeRed[230]);
    return redPartialReady;
  }
  bool refreshRed(const FrameCanvas& before,const FrameCanvas& after) {
    if(!redPartialReady || digitalRead(4)==HIGH)return false;
    _writeCommand(0x32);for(uint8_t value:redLut)_writeData(value);
    uint8_t check[233];readRegister(0x33,check,233);
    if(memcmp(check,redLut,227) || memcmp(check+227,nativeRed+227,6)) {
      redPartialReady=false;return false; // no activation on incompatible readback
    }
    for(uint8_t command:{uint8_t(0x24),uint8_t(0x26)}) {
      _writeCommand(0x11);_writeData(3);
      _writeCommand(0x44);_writeData(0);_writeData(49);
      _writeCommand(0x45);_writeData(0);_writeData(0);_writeData(0x2b);_writeData(1);
      _writeCommand(0x4e);_writeData(0);_writeCommand(0x4f);_writeData(0);_writeData(0);
      _writeCommand(command);_startTransfer();
      for(size_t i=0;i<FrameCanvas::BYTES;++i) {
        auto delta=redTransition(before.red[i],after.red[i]);
        _transfer(command==0x24?delta.bw:delta.red);
      }
      _endTransfer();
    }
    normalGate();_writeCommand(0x21);_writeData(0);_writeData(0);
    _writeCommand(0x3c);_writeData(0xc0);_busy_timeout=30000000;
    uint32_t start=millis();
    _writeCommand(0x22);_writeData(0xc7);_writeCommand(0x20);
    delay(2);bool sawBusy=digitalRead(4)==HIGH;
    _waitWhileBusy("STOCK_RED_HOLD",30000);_power_is_on=false;
    uint32_t elapsed=millis()-start;
    bool ok=sawBusy && digitalRead(4)==LOW && elapsed+1000>=redInfo.nominalMilliseconds && elapsed<redInfo.nominalMilliseconds+3000;
    Serial.printf("RED_PARTIAL_DONE elapsed_ms=%lu valid=%d\n",static_cast<unsigned long>(elapsed),ok);
    allowLongRefresh();return ok;
  }
  bool refreshBwWindow(int x,int y,int w,int h) {
    if(x<0 || y<0 || w<8 || h<1 || x+w>400 || y+h>300 || x%8 || w%8)return false;
    _busy_timeout=8000000;
    normalGate();
    _writeCommand(0x21);_writeData(0x00);_writeData(0x00);
    _writeCommand(0x3c);_writeData(0xc0); // border Hi-Z
    _writeCommand(0x22);_writeData(0xc0);_writeCommand(0x20);
    _waitWhileBusy("CUSTOM_LUT_POWER_ON",100);
    if(digitalRead(4)==HIGH)return false;
    // Preserve native gate/source/VCOM voltages and end/frame parameters.
    // Only the 227 main waveform bytes are transferred, not the six extras.
    _writeCommand(0x32);
    for(uint8_t value:ssd1619PartialLut)_writeData(value);
    _writeCommand(0x11);_writeData(0x03);
    _writeCommand(0x44);_writeData(x/8);_writeData((x+w-1)/8);
    _writeCommand(0x45);_writeData(y&255);_writeData(y>>8);_writeData((y+h-1)&255);_writeData((y+h-1)>>8);
    _writeCommand(0x4e);_writeData(x/8);
    _writeCommand(0x4f);_writeData(y&255);_writeData(y>>8);
    uint32_t start=millis();
    // CF activates black/white Mode 2 WITHOUT loading OTP over the custom LUT.
    _writeCommand(0x22);_writeData(0xcf);_writeCommand(0x20);
    _waitWhileBusy("LONG_LUT_CUSTOM_PARTIAL",8000);
    _power_is_on=false;
    bool ready=digitalRead(4)==LOW;
    Serial.printf("LUT_WINDOW_DONE x=%d y=%d w=%d h=%d bytes=227 update=CF elapsed_ms=%lu BUSY=%d\n",x,y,w,h,static_cast<unsigned long>(millis()-start),digitalRead(4));
    return ready;
  }
};
static GxEPD2_3C<HinkPanel, 32> display(HinkPanel(10, 13, 7, 4));
static NativeText font;
static Adafruit_GFX* painter=&display;
static bool renderBw=false;
static uint32_t busyStart, lastBusyLog, busyCallbacks;

static void label(int x, int y, const String& text, uint16_t color = GxEPD_BLACK, bool right = false) {
  font.setForegroundColor(color);
  if (right) x -= font.getUTF8Width(text.c_str());
  font.setCursor(x, y); font.print(text);
}

static void heading(int x,int y,const String& text,uint16_t color=GxEPD_BLACK,bool right=false) {
  int width=styleWidth(text,Header18);
  if(width<0) { label(x,y,text,color,right);return; }
  styleText(*painter,right?x-width:x,y,text,Header18,color);
}
enum class PixelFace { Axis, Small, Quote };
static void latin(int x,int y,const String& text,PixelFace face,uint16_t color=GxEPD_BLACK,bool right=false,int size=1) {
  if(face!=PixelFace::Quote) { label(x,y,text,color,right);return; }
  const StyleFont& chosen=size>1 ? Clock80 : Quote48;
  int width=styleWidth(text,chosen);
  styleText(*painter,right?x-width:x,y,text,chosen,color);
}

static String clipped(const String& input, int count) {
  int characters = 0, end = 0;
  for (unsigned int i = 0; i < input.length(); ++i) {
    if ((static_cast<uint8_t>(input[i]) & 0xc0) != 0x80) {
      if (characters++ == count) break;
    }
    end = i + 1;
  }
  return input.substring(0, end);
}

static void bigName(const String& text) {
  if(styleWidth(text,Title26)<0) { label(20,73,clipped(text,13),GxEPD_BLACK);return; }
  styleText(*painter,20,73,text,Title26,GxEPD_BLACK);
}

static String phaseLabel(Phase p) {
  switch (p) {
    case Phase::Auction: return "集合竞价";
    case Phase::Opening: return "待开盘";
    case Phase::Trading: return "交易中";
    case Phase::Closing: return "收盘竞价";
    case Phase::Unknown: return "日历待更新";
    default: return "已休市";
  }
}

static void weatherIcon(int code) {
  if (code < 104) {
    painter->drawCircle(46, 213, 12, GxEPD_BLACK);
    for (int i = 0; i < 8; ++i) {
      float a = i * PI / 4;
      painter->drawLine(46+17*cos(a), 213+17*sin(a), 46+22*cos(a), 213+22*sin(a), GxEPD_BLACK);
    }
  }
  if (code != 100 && code != 150) {
    painter->fillRect(29, 222, 40, 20, GxEPD_WHITE);
    painter->drawCircle(40, 228, 12, GxEPD_BLACK);
    painter->drawCircle(54, 221, 14, GxEPD_BLACK);
    painter->drawCircle(67, 231, 10, GxEPD_BLACK);
    painter->fillRect(33, 228, 40, 12, GxEPD_WHITE);
    painter->drawFastHLine(34, 241, 34, GxEPD_BLACK);
    if (code >= 300 && code < 500) for (int x = 38; x <= 66; x += 12) painter->drawLine(x, 247, x-3, 253, GxEPD_BLACK);
  }
}

static void drawClock(const tm& now, bool valid, const Weather& w, const String& city, Phase phase) {
  char date[40], time[12];
  if (valid) { snprintf(date, sizeof(date), "%04d.%02d.%02d", now.tm_year+1900, now.tm_mon+1, now.tm_mday); snprintf(time, sizeof(time), "%02d:%02d",now.tm_hour,now.tm_min); }
  else { strcpy(date, "等待阿里云校时"); strcpy(time, "--:--"); }
  heading(20, 29, date);
  if (valid) { const char* days[] = {"周日", "周一", "周二", "周三", "周四", "周五", "周六"}; heading(380, 29, days[now.tm_wday], GxEPD_BLACK, true); }
  latin((400-styleWidth(String(time),Clock80))/2, 145, time, PixelFace::Quote, GxEPD_BLACK, false, 2);
  painter->drawFastHLine(20, 169, 360, GxEPD_BLACK);
  weatherIcon(w.valid ? w.icon : 104);
  latin(88, 237, w.valid ? String(w.temp, 0) : "--", PixelFace::Quote);
  String temperature = w.valid ? String(w.temp,0) : "--";
  painter->drawCircle(min(205,88+static_cast<int>(temperature.length())*30+8), 207, 3, GxEPD_BLACK);
  label(220, 215, w.valid ? clipped(w.text, 6) : "天气待更新");
  label(220, 242, clipped(city, 6));
  String footer = "和风天气";
  if (!w.valid) footer += " · 未获取";
  else if (!weatherError.isEmpty() || ::time(nullptr)-w.receivedAt > 3600) footer += " · 缓存";
  label(20, 293, footer);
  if (w.dailyValid) label(380, 293, String(w.low,0)+" / "+String(w.high,0)+" C", GxEPD_BLACK, true);
  if (phase == Phase::Unknown) label(20, 60, "请更新交易日历", GxEPD_RED);
}

static void drawStock(const tm& now, const Stock& s, const Weather& w, const String& city,
                      Phase phase, int index, bool stale) {
  const int visible=s.count;
  const float price=s.price;
  const float change=price-s.previous;
  const float percent=s.previous>0 ? change/s.previous*100 : 0;
  const bool visiblePrice=s.valid;
  char date[24]; snprintf(date, sizeof(date), "%02d.%02d  %02d:%02d", now.tm_mon+1, now.tm_mday, now.tm_hour, now.tm_min);
  heading(20, 27, date);
  heading(380, 27, clipped(city, 4)+" "+(w.valid ? String(w.temp,0) : "--")+" C", GxEPD_BLACK, true);
  painter->drawFastHLine(20, 38, 360, GxEPD_BLACK);
  bigName(s.valid ? s.name : cfg.stocks[index]);
  char todayBuffer[9]; strftime(todayBuffer,sizeof(todayBuffer),"%Y%m%d",&now);
  String today = todayBuffer;
  bool historical = s.valid && s.stamp.substring(0,8) != today;
  label(380, 69, historical ? "历史行情" : stale ? "数据延迟" : phaseLabel(phase), renderBw?GxEPD_BLACK:GxEPD_RED, true);
  if(historical && s.minuteDate.length()==8) {
    String sourceDate=s.minuteDate.substring(0,4)+"-"+s.minuteDate.substring(4,6)+"-"+s.minuteDate.substring(6,8);
    label(380,93,sourceDate,GxEPD_BLACK,true);
  }
  uint16_t color = !renderBw && change > 0 ? GxEPD_RED : GxEPD_BLACK;
  latin(18, 120, visiblePrice ? String(price,2) : "--.--", PixelFace::Quote, renderBw?GxEPD_BLACK:GxEPD_RED);
  String delta = visiblePrice ? (change > 0 ? "+" : "")+String(change,2)+"  "+(percent > 0 ? "+" : "")+String(percent,2)+"%" : "--  --%";
  latin(380, 120, delta, PixelFace::Small, color, true);
  bool auction = (phase == Phase::Auction || phase == Phase::Opening) && !historical;
  bool hasCurve = s.valid && s.count > 0 && !auction;
  if (hasCurve) {
    const int left = 54, right = 334, top = 136, bottom = 284;
    float lo = s.previous, hi = s.previous;
    for (int i = 0; i < s.count; ++i) {
      lo = min(lo, s.points[i].price); hi = max(hi, s.points[i].price);
      if (isfinite(s.points[i].average)) { lo = min(lo, s.points[i].average); hi = max(hi, s.points[i].average); }
    }
    float margin = max((hi-lo)*0.1f, s.previous*0.002f);
    lo -= margin; hi += margin;
    auto py = [&](float v) { return bottom-static_cast<int>(lround((v-lo)/(hi-lo)*(bottom-top))); };
    for (int xx = left; xx <= right; xx += 8) painter->drawFastHLine(xx, py(s.previous), min(4, right-xx+1), GxEPD_BLACK);
    for (int i = 1; i < visible; ++i) {
      int x0 = left+s.points[i-1].offset*(right-left)/240, x1 = left+s.points[i].offset*(right-left)/240;
      painter->drawLine(x0,py(s.points[i-1].price),x1,py(s.points[i].price),GxEPD_BLACK);
      if (isfinite(s.points[i-1].average) && isfinite(s.points[i].average) && (!renderBw || i%3!=0)) painter->drawLine(x0,py(s.points[i-1].average),x1,py(s.points[i].average),renderBw?GxEPD_BLACK:GxEPD_RED);
    }
    label(50, top+6, String(hi,hi>=1000 ? 0 : 2), GxEPD_BLACK, true);
    label(50, bottom+4, String(lo,lo>=1000 ? 0 : 2), GxEPD_BLACK, true);
    label(395, top+6, String((hi/s.previous-1)*100,2)+"%", renderBw?GxEPD_BLACK:GxEPD_RED, true);
    label(395, bottom+4, String((lo/s.previous-1)*100,2)+"%", GxEPD_BLACK, true);
  } else {
    label(30, 184, auction ? "集合竞价 · 等待正式开盘" : "等待有效分时数据");
    label(30, 215, stockError.length() ? clipped(stockError,14) : "分时线从09:30开始绘制");
  }
}

#include "cards_draw.h"

static void busyCallback(const void*) {
  ++busyCallbacks; serviceWeb();
  if (millis()-lastBusyLog > 5000) {
    lastBusyLog = millis();
    Serial.printf("DISPLAY_BUSY elapsed_ms=%lu BUSY=%d\n", static_cast<unsigned long>(millis()-busyStart), digitalRead(4));
  }
  delay(1);
}

void initScreen() {
  SPI.begin(12, -1, 11, 10);
  display.epd2.selectSPI(SPI, SPISettings(4000000, MSBFIRST, SPI_MODE0));
  display.epd2.allowLongRefresh(); display.epd2.setBusyCallback(busyCallback);
  display.init(115200);
  display.setRotation(0); display.epd2.selectFastFullUpdate(false);
  font.begin(display); font.setScale(1);
}

static bool partialFailed=false, baselineValid=false, fullFailed=false;
static String previousTag, previousLayout;
static uint32_t previousRevision=0,lastFull=0;
static uint32_t oldRegionHash[3]={},oldRedHash=0;
static FrameCanvas* previousFrame=nullptr;

static bool partialRegion(FrameCanvas& frame,int x,int y,int w,int h,const char* kind,bool holdRed=false) {
  if(!holdRed && frame.hasRed(x,y,w,h)) return false;
  display.epd2.partialTimeout();
  uint32_t start=millis(),callbacksBefore=busyCallbacks;
  display.epd2.writeImagePartToCurrent(frame.black,x,y,400,300,x,y,w,h);
  bool ready=display.epd2.refreshBwWindow(x,y,w,h);
  uint32_t elapsed=millis()-start;
  display.epd2.allowLongRefresh();
  if(!ready || digitalRead(4)==HIGH || elapsed>8100 || elapsed<100 || busyCallbacks==callbacksBefore) {
    partialFailed=true;partialStatus="partial_failed_recovery_pending";
    displayError="局刷异常，准备全刷恢复";
    Serial.printf("PARTIAL_FAILED region=%s elapsed_ms=%lu BUSY=%d\n",kind,static_cast<unsigned long>(elapsed),digitalRead(4));
    return false;
  }
  display.epd2.writeImagePartToPrevious(frame.black,x,y,400,300,x,y,w,h);
  partialStatus="custom_lut_busy_passed_visual_pending";++partialRefreshCount;
  Serial.printf("PARTIAL_DONE region=%s elapsed_ms=%lu\n",kind,static_cast<unsigned long>(elapsed));
  return true;
}

void refreshScreen() {
  if(fullFailed)return;
  if(partialFailed && !baselineValid && digitalRead(4)==HIGH)return;
  time_t epoch=time(nullptr);tm now{};localtime_r(&epoch,&now);
  const bool online=WiFi.status()==WL_CONNECTED,valid=clockReady();
  const Phase phase=currentPhase();
  const bool stocks=showingStock();
  const CardId card=selectedCard();
  const bool colorPartial=cfg.refreshMode=="color_partial";
  const bool useBw=cfg.partialEnabled && cfg.refreshMode!="color_full" && !partialFailed;
  const bool stockRed=stocks && colorPartial && useBw;
  if(stockRed && !previousFrame)previousFrame=new FrameCanvas;
  const bool canRed=stockRed && previousFrame && previousFrame->valid() && redPartialReady;
  const bool maintenanceFull=baselineValid && (stocks ? stockFullRefreshDue(millis(),lastFull) : millis()-lastFull>=900000UL);
  char clock[24];strftime(clock,sizeof(clock),"%Y%m%d%H%M",&now);
  String layout=String(stocks)+"|"+(stocks?cfg.stocks[activeStock]:String(CARD_CHOICES[static_cast<int>(card)].code))+"|"+String(online)+"|"+String(clock).substring(0,8)+"|"+String(phase==Phase::Unknown);
  String weatherKey=weather.location+weather.observedAt+String(weather.temp)+weather.text+String(weather.low)+String(weather.high)+weatherError;
  uint32_t pointHash=2166136261u;
  for(int i=0;i<stock.count;++i) {
    const uint8_t* bytes=reinterpret_cast<const uint8_t*>(&stock.points[i]);
    for(size_t j=0;j<sizeof(Point);++j)pointHash=(pointHash^bytes[j])*16777619u;
  }
  String tag=String(clock)+String(settingsRevision)+weatherKey+layout+String(stock.price,4)+String(stock.previous,4)+String(pointHash)+stock.stamp.substring(0,8)+stockError+phaseCode(phase);
  bool full=!baselineValid || maintenanceFull || layout!=previousLayout || settingsRevision!=previousRevision;
  if(!full && tag==previousTag) { needRefresh=false;return; }
  if(!full && !useBw && millis()-lastFull<120000UL)return;
  FrameCanvas frame;
  if(!frame.valid()) { displayError="绘图内存不足";return; }
  painter=&frame;font.begin(frame);font.setScale(1);cardDrawingFailed=false;styleDrawingFailed=false;renderBw=cfg.refreshMode=="bw_partial";
  if(!online && apActive) {
    label(20,45,"墨水屏联网设置");label(20,95,"请连接设备热点后打开");label(20,125,"http://192.168.4.1");
    label(20,165,"热点: EPaper-"+String(static_cast<uint32_t>(ESP.getEfuseMac()),HEX));
    label(20,195,"密码: "+cfg.adminPassword);label(20,225,"网页用户: admin");full=true;
  } else if(stocks && valid) {
    drawStock(now,stock,weather,cfg.city,phase,activeStock,!stockError.isEmpty() || (stock.valid && epoch-stock.receivedAt>cfg.refreshSeconds*2));
  } else if(valid) { drawCard(card,now);if(phase==Phase::Unknown)label(18,66,"日历待更新"); }
  else drawClock(now,valid,weather,cfg.city,phase);
  if(cardDrawingFailed || styleDrawingFailed) { displayError="字模解压失败"; painter=&display;font.begin(display);needRefresh=true;return; }
  frame.fillRect(8,12,4,16,GxEPD_RED);
  struct Region { int x,y,w,h;const char* name; };
  Region regions[3]{};int count=0;
  if(stocks) { regions[0]={16,0,384,40,"header"};regions[1]={0,40,400,260,"stock"};count=2; }
  else if(!valid) { regions[0]={16,0,384,40,"header"};regions[1]={40,64,320,96,"clock"};regions[2]={0,176,400,124,"weather"};count=3; }
  else switch(card) {
    case CardId::BigCalendar:regions[0]={280,0,120,48,"time"};regions[1]={0,240,400,60,"weather"};count=2;break;
    case CardId::MonthWeather:regions[0]={16,192,104,48,"time"};regions[1]={0,244,400,56,"weather"};count=2;break;
    case CardId::Almanac:regions[0]={288,268,112,32,"time"};count=1;break;
    case CardId::MinimalClock:regions[0]={40,80,320,120,"time"};regions[1]={0,224,400,76,"weather"};count=2;break;
    case CardId::Overview:regions[0]={160,64,240,88,"time"};regions[1]={0,168,400,40,"weather"};regions[2]={0,216,400,84,"quote"};count=3;break;
  }
  uint32_t hashes[3]={};bool changed[3]={};bool anyChanged=false;
  for(int i=0;i<count;++i) { auto r=regions[i];hashes[i]=frame.hash(frame.black,r.x,r.y,r.w,r.h);changed[i]=hashes[i]!=oldRegionHash[i];anyChanged|=changed[i];if(changed[i] && frame.hasRed(r.x,r.y,r.w,r.h) && !canRed)full=true; }
  const uint32_t redHash=frame.hash(frame.red,0,0,400,300);
  const bool redChanged=redHash!=oldRedHash;
  full=full || !useBw || (redChanged && !canRed);
  if(!full && !anyChanged && !redChanged) { previousTag=tag;needRefresh=false;painter=&display;font.begin(display);return; }
  const bool changedLayout=!baselineValid || layout!=previousLayout;
  rendering=true;needRefresh=false;busyStart=lastBusyLog=millis();bool success=true;
  if(full) {
    if(maintenanceFull)Serial.printf("MAINTENANCE_FULL view=%s interval_ms=%lu\n",stocks?"stock":"clock",static_cast<unsigned long>(stocks?STOCK_FULL_REFRESH_INTERVAL_MS:900000UL));
    display.epd2.allowLongRefresh();display.epd2.restoreColorRegisters();display.epd2.normalGate();
    display.epd2.writeImage(frame.black,frame.red,0,0,400,300);display.epd2.refresh(false);
    if(digitalRead(4)==HIGH || millis()-busyStart<1000) {
      success=false;fullFailed=true;displayError="全刷初始化未通过";partialStatus="full_initialization_failed";
    } else {
      ++fullRefreshCount;lastFull=millis();
      if(colorPartial)display.epd2.cacheRedWaveform();
      if(useBw) {
        display.epd2.writeImageToCurrent(frame.black,0,0,400,300);
        display.epd2.writeImageToPrevious(frame.black,0,0,400,300);
        partialStatus="ready";
      } else { display.hibernate();partialStatus=partialFailed?"disabled_after_failure":"disabled"; }
      displayError="";
    }
    lastFrameKind="full";
  } else {
    if(canRed && redChanged) {
      success=display.epd2.refreshRed(*previousFrame,frame);
      if(success) {
        // Red pass uses both RAM planes as masks. Restore differential B/W
        // history, treating red-touched pixels as white after forming/erasing.
        for(size_t i=0;i<FrameCanvas::BYTES;++i)
          previousFrame->black[i]=redTransition(previousFrame->red[i],frame.red[i]).blackAfterRed(previousFrame->black[i]);
        display.epd2.writeImageToPrevious(previousFrame->black,0,0,400,300);
        display.epd2.writeImageToCurrent(frame.black,0,0,400,300);
        // Always finish the stock region: red->black may leave the logical
        // black hash unchanged even though the red pass erased that pixel.
        changed[1]=true;
      } else {
        partialFailed=true;redPartialReady=false;
        displayError="红色局刷异常，准备全刷恢复";
        partialStatus="red_partial_failed_recovery_pending";
      }
    }
    for(int i=0;i<count && success;++i)if(changed[i]) { auto r=regions[i];success=partialRegion(frame,r.x,r.y,r.w,r.h,r.name,canRed); }
    lastFrameKind=canRed && redChanged?"color_partial":"partial";
    if(success)displayError="";
  }
  lastFrameElapsedMs=millis()-busyStart;lastRefreshMs=millis();rendering=false;
  if(success) {
    if(stockRed && previousFrame && previousFrame->valid()) {
      memcpy(previousFrame->black,frame.black,FrameCanvas::BYTES);
      memcpy(previousFrame->red,frame.red,FrameCanvas::BYTES);
    }
    baselineValid=true;previousTag=tag;previousLayout=layout;previousRevision=settingsRevision;
    for(int i=0;i<count;++i)oldRegionHash[i]=hashes[i];oldRedHash=redHash;
    lastDisplayedEpoch=epoch;displayedView=stocks?"stock":CARD_CHOICES[static_cast<int>(card)].code;
    if(!stocks && changedLayout)noteCardShown();
  } else baselineValid=false;
  Serial.printf("DISPLAY_DONE kind=%s view=%s elapsed_ms=%lu full=%lu partial=%lu BUSY=%d\n",lastFrameKind.c_str(),stocks?"stock":"clock",static_cast<unsigned long>(lastFrameElapsedMs),static_cast<unsigned long>(fullRefreshCount),static_cast<unsigned long>(partialRefreshCount),digitalRead(4));
  painter=&display;font.begin(display);
}
