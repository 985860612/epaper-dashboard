#pragma once
#include "generated_styles.h"
#include <miniz.h>
inline bool styleDrawingFailed=false;

inline uint32_t styleCode(const char*& p) {
  uint8_t c=static_cast<uint8_t>(*p++);if(c<128)return c;
  int n=c<0xe0 ? 1 : c<0xf0 ? 2 : 3;uint32_t v=c&((1u<<(6-n))-1);
  while(n-- && *p)v=(v<<6)|(static_cast<uint8_t>(*p++)&63);return v;
}
inline const StyleGlyph* styleGlyph(const StyleFont& font,uint32_t code) {
  for(int i=0;i<font.count;++i)if(font.glyphs[i].code==code)return &font.glyphs[i];return nullptr;
}
inline int styleWidth(const String& text,const StyleFont& font) {
  int width=0;const char* p=text.c_str();while(*p){auto g=styleGlyph(font,styleCode(p));if(!g)return -1;width+=g->advance;}return width;
}
inline void styleText(Adafruit_GFX& d,int x,int baseline,const String& text,const StyleFont& font,uint16_t color) {
  uint8_t* expanded=nullptr;const uint8_t* bits=font.bits;
  if(font.packedBytes) {
    expanded=static_cast<uint8_t*>(malloc(font.rawBytes));
    if(!expanded || tinfl_decompress_mem_to_mem(expanded,font.rawBytes,font.bits,font.packedBytes,TINFL_FLAG_PARSE_ZLIB_HEADER|TINFL_FLAG_USING_NON_WRAPPING_OUTPUT_BUF)!=font.rawBytes) {
      free(expanded);styleDrawingFailed=true;return;
    }
    bits=expanded;
  }
  const char* p=text.c_str();while(*p){auto g=styleGlyph(font,styleCode(p));if(!g)continue;d.drawBitmap(x+g->dx,baseline+g->dy,bits+g->offset,g->width,g->height,color);x+=g->advance;}
  free(expanded);
}
