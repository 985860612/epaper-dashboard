#pragma once
constexpr int FONT_TEST_FIRST_Y=66;
constexpr int FONT_TEST_ROW_HEIGHT=34;
constexpr int FONT_TEST_SAMPLE_X=108;
static void drawFontTest(const tm& now) {
  label(20,27,"字体对照 20px");
  cardNumber(382,29,cardTime(now),Card24,GxEPD_BLACK,true);
  painter->drawFastHLine(18,36,364,GxEPD_BLACK);
  const StyleFont* faces[]={&CardText20,&TestArial20,&TestSemi20,&TestRou20,&TestNoto20,&TestJing20,&TestJingXi20};
  const char* titles[]={"当前","A 苹中","B 苹黑","C 源柔","D Noto","E 晶黑","F 晶细"};
  for(unsigned row=0;row<sizeof(faces)/sizeof(faces[0]);++row) {
    int y=FONT_TEST_FIRST_Y+row*FONT_TEST_ROW_HEIGHT;label(20,y-2,titles[row]);
    const auto& face=*faces[row];
    styleText(*painter,FONT_TEST_SAMPLE_X,y,"北京 星期一",face,GxEPD_BLACK);
    const String digits="0123456789";
    styleText(*painter,382-styleWidth(digits,face),y,digits,face,GxEPD_RED);
    painter->drawFastHLine(18,y+6,364,GxEPD_BLACK);
  }
  label(20,296,"C/E缺顺义 · 原生20px字模");
}
