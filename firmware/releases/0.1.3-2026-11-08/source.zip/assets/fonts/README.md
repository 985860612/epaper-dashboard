# 像素字库来源

中文使用 [Fusion Pixel Font](https://github.com/TakWolf/fusion-pixel-font)，版本`2026.10.25`的12px等宽简体字形。保留上游OTF、[OFL授权](OFL.txt)及`LICENSES/`中的来源字库授权。

原始发布文件：`fusion-pixel-font-12px-monospaced-otf-v2026.10.25.zip`，来自[上游发布页](https://github.com/TakWolf/fusion-pixel-font/releases/tag/2026.10.25)，归档SHA-256：`6e4cd37ad32ccdab76858759397a01c3ec372ac37fdf3acf0705da7b44281302`。

`tools/build_fonts.py`按原始12px网格生成1位字模（ascent10、descent2），中文界面以2倍整数像素绘制，保留原始点阵笔画，不做轮廓字加粗或灰度缩放。固件只嵌入字符子集的压缩字模，不加载整个OTF。

数字使用Adafruit GFX内置标准5×7像素字形，价格5倍、时间9倍、小数字2倍。运行时不依赖字体服务或电脑。
