#pragma once
#include "almanac.h"
#include <miniz.h>
static bool cardDrawingFailed=false;

static void cardNumber(int x,int baseline,const String& value,const StyleFont& face,uint16_t color=GxEPD_BLACK,bool right=false) {
  int origin=right?x-styleWidth(value,face):x;
  if(&face==&Day128) {
    uint8_t* raw=static_cast<uint8_t*>(malloc(DAY128_RAW_BYTES));
    if(!raw) { cardDrawingFailed=true;displayError="大字字模内存不足";return; }
    size_t n=tinfl_decompress_mem_to_mem(raw,DAY128_RAW_BYTES,Day128Bits,sizeof(Day128Bits),TINFL_FLAG_PARSE_ZLIB_HEADER|TINFL_FLAG_USING_NON_WRAPPING_OUTPUT_BUF);
    if(n!=DAY128_RAW_BYTES) { free(raw);cardDrawingFailed=true;displayError="大字字模解压失败";return; }
    StyleFont expanded={raw,Day128Glyphs,Day128.count};styleText(*painter,origin,baseline,value,expanded,color);free(raw);
  } else styleText(*painter,origin,baseline,value,face,color);
}
static String cardTime(const tm& now) {
  char value[6];snprintf(value,sizeof(value),"%02d:%02d",now.tm_hour,now.tm_min);return value;
}
static String cardDate(const tm& now) {
  char value[16];snprintf(value,sizeof(value),"%04d.%02d.%02d",now.tm_year+1900,now.tm_mon+1,now.tm_mday);return value;
}
static String cardDay(const tm& now) {
  return String(now.tm_mday<10?"0":"")+String(now.tm_mday);
}
static const char* const CARD_WEEKDAYS[]={"星期日","星期一","星期二","星期三","星期四","星期五","星期六"};
static void cardHeader(const String& title,const String& detail) {
  painter->fillRect(18,18,4,19,GxEPD_RED);label(32,34,title);label(382,34,detail,GxEPD_BLACK,true);
  painter->drawFastHLine(18,47,364,GxEPD_BLACK);
}
static void cardCloud(int x,int y) {
  painter->drawCircle(x+11,y+15,9,GxEPD_BLACK);painter->drawCircle(x+22,y+9,11,GxEPD_BLACK);painter->drawCircle(x+34,y+15,8,GxEPD_BLACK);
  painter->fillRect(x+5,y+15,34,10,GxEPD_WHITE);painter->drawFastHLine(x+7,y+24,30,GxEPD_BLACK);
}
static void cardWeatherFooter(int y) {
  painter->drawFastHLine(18,y-20,364,GxEPD_BLACK);cardCloud(18,y-8);
  String value=clipped(cfg.city,5)+"  "+(weather.valid?String(weather.temp,0)+" C":"天气待更新");
  label(64,y+13,value);
  if(weather.dailyValid)label(382,y+13,String(weather.low,0)+" / "+String(weather.high,0)+" C",GxEPD_BLACK,true);
  if(!weatherError.isEmpty() || (weather.valid && time(nullptr)-weather.receivedAt>3600))label(18,299,"天气缓存");
}
static void drawBigCalendar(const tm& now) {
  cardHeader(String(now.tm_year+1900)+"年 "+String(now.tm_mon+1)+"月","");
  cardNumber(382,37,cardTime(now),Card24,GxEPD_BLACK,true);label(382,74,CARD_WEEKDAYS[now.tm_wday],GxEPD_BLACK,true);
  const String day=cardDay(now);cardNumber((400-styleWidth(day,Day128))/2,214,day,Day128,GxEPD_RED);
  cardWeatherFooter(262);
}
static void drawMonthWeather(const tm& now) {
  cardHeader(String(now.tm_year+1900)+"年"+String(now.tm_mon+1)+"月",CARD_WEEKDAYS[now.tm_wday]);
  const String day=cardDay(now);cardNumber(66-styleWidth(day,Clock80)/2,155,day,Clock80,GxEPD_RED);
  label(66-font.getUTF8Width(CARD_WEEKDAYS[now.tm_wday])/2,184,CARD_WEEKDAYS[now.tm_wday]);
  cardNumber(66-styleWidth(cardTime(now),Card24)/2,219,cardTime(now),Card24);
  painter->drawFastVLine(126,65,166,GxEPD_BLACK);
  const char* wd[]={"日","一","二","三","四","五","六"};
  for(int i=0;i<7;++i)label(143+i*34,83,wd[i],i==0||i==6?GxEPD_RED:GxEPD_BLACK);
  painter->drawFastHLine(137,91,244,GxEPD_BLACK);
  int first=(now.tm_wday-(now.tm_mday-1)%7+7)%7;
  int days=calendarMonthDays(now.tm_year+1900,now.tm_mon+1);
  // Six-row months also fit above the weather separator.
  int rows=(first+days+6)/7,step=rows==6?22:25;
  for(int d=1;d<=days;++d) {
    int slot=first+d-1,col=slot%7,row=slot/7,x=151+col*34,y=115+row*step;
    uint16_t color=col==0||col==6?GxEPD_RED:GxEPD_BLACK;
    if(d==now.tm_mday) { painter->fillRect(x-13,y-18,26,24,GxEPD_RED);color=GxEPD_WHITE; }
    String value=String(d);label(x-font.getUTF8Width(value.c_str())/2,y,value,color);
  }
  cardWeatherFooter(264);
}
static void drawAlmanac(const tm& now) {
  cardHeader("黄历",cardDate(now));cardNumber(18,140,cardDay(now),Clock80,GxEPD_RED);
  int index=almanacIndex(now.tm_year+1900,now.tm_mon+1,now.tm_mday);
  if(index<0) { label(150,104,"黄历数据待更新");label(150,135,"支持2026至2028年"); }
  else {
    uint16_t packed=lunarPacked(index);int month=((packed>>5)&15),day=(packed&31),gz=packed>>10;
    const char* months[]={"正","二","三","四","五","六","七","八","九","十","冬","腊"};
    const char* days[]={"初一","初二","初三","初四","初五","初六","初七","初八","初九","初十","十一","十二","十三","十四","十五","十六","十七","十八","十九","二十","廿一","廿二","廿三","廿四","廿五","廿六","廿七","廿八","廿九","三十"};
    const char* gan[]={"甲","乙","丙","丁","戊","己","庚","辛","壬","癸"};
    const char* zhi[]={"子","丑","寅","卯","辰","巳","午","未","申","酉","戌","亥"};
    label(150,98,String("农历")+((packed&512)?"闰":"")+months[month]+"月"+days[day]);
    label(150,133,String(gan[gz%10])+zhi[gz%12]+"年");label(382,133,CARD_WEEKDAYS[now.tm_wday],GxEPD_BLACK,true);
    for(int row=0;row<2;++row) {
      int y=201+row*44;uint16_t tile=row?GxEPD_BLACK:GxEPD_RED;
      painter->fillRect(18,y-23,31,31,tile);label(25,y,row?"忌":"宜",GxEPD_WHITE);
      int a=ALMANAC_DAYS[index][2+row*2],b=ALMANAC_DAYS[index][3+row*2];
      label(68,y,String(ALMANAC_WORDS[a])+(b?String("  ")+ALMANAC_WORDS[b]:""));
    }
  }
  painter->drawFastHLine(18,160,364,GxEPD_BLACK);painter->drawFastHLine(18,267,364,GxEPD_BLACK);
  label(18,290,"宜忌节选 · 民俗参考");cardNumber(382,290,cardTime(now),Card24,GxEPD_BLACK,true);
}
static void drawMinimalClock(const tm& now) {
  cardHeader(cardDate(now),CARD_WEEKDAYS[now.tm_wday]);String value=cardTime(now);
  cardNumber((400-styleWidth(value,Clock80))/2,179,value,Clock80);
  painter->drawFastHLine(18,209,364,GxEPD_BLACK);cardCloud(18,236);
  String temp=weather.valid?String(weather.temp,0):"--";cardNumber(79,268,temp,Quote48);painter->drawCircle(79+styleWidth(temp,Quote48)+8,234,3,GxEPD_BLACK);
  label(382,243,weather.valid?clipped(weather.text,6):"天气待更新",GxEPD_BLACK,true);
  label(382,274,clipped(cfg.city,5)+(weather.dailyValid?"  "+String(weather.low,0)+" / "+String(weather.high,0)+" C":""),GxEPD_BLACK,true);
  if(!weatherError.isEmpty())label(18,299,"天气缓存");
}
static void drawOverview(const tm& now) {
  cardHeader("今日总览",String(now.tm_year+1900)+"年"+String(now.tm_mon+1)+"月");
  cardNumber(18,141,cardDay(now),Clock80,GxEPD_RED);painter->drawFastVLine(142,66,87,GxEPD_BLACK);
  cardNumber(382,111,cardTime(now),Quote48,GxEPD_BLACK,true);label(382,143,CARD_WEEKDAYS[now.tm_wday],GxEPD_BLACK,true);
  painter->drawFastHLine(18,165,364,GxEPD_BLACK);cardCloud(18,177);label(64,201,clipped(cfg.city,5)+" "+(weather.valid?clipped(weather.text,4):"待更新"));
  cardNumber(360,202,weather.valid?String(weather.temp,0):"--",Card24,GxEPD_BLACK,true);label(382,202,"C",GxEPD_BLACK,true);
  painter->drawFastHLine(18,215,364,GxEPD_BLACK);label(18,239,stock.valid?clipped(stock.name,8):cfg.stocks[0]);
  String stamp=stock.valid?stock.stamp.substring(4,6)+"."+stock.stamp.substring(6,8)+" "+stock.stamp.substring(8,10)+":"+stock.stamp.substring(10,12):"行情待更新";
  label(382,239,stamp,GxEPD_BLACK,true);cardNumber(18,281,stock.valid?String(stock.price,2):"--.--",Card24);
  String change=stock.valid?(stock.change>0?"+":"")+String(stock.percent,2)+"%":"--%";
  cardNumber(382,279,change,Card24,GxEPD_BLACK,true);
  if(stock.valid && stock.count>1) {
    float lo=stock.points[0].price,hi=lo;for(int i=1;i<stock.count;++i) {lo=min(lo,stock.points[i].price);hi=max(hi,stock.points[i].price);}
    if(hi<=lo)hi=lo+0.01f;
    for(int i=1;i<stock.count;++i)painter->drawLine(163+stock.points[i-1].offset*105/240,281-(stock.points[i-1].price-lo)*38/(hi-lo),163+stock.points[i].offset*105/240,281-(stock.points[i].price-lo)*38/(hi-lo),GxEPD_BLACK);
  }
  if(stock.valid && stock.stamp.substring(0,8)!=dateCompact())label(18,299,"历史行情");
  else if(!stockError.isEmpty())label(18,299,"行情缓存");
}
static void drawCard(CardId id,const tm& now) {
  cardDrawingFailed=false;
  switch(id) {
    case CardId::BigCalendar:drawBigCalendar(now);break;
    case CardId::MonthWeather:drawMonthWeather(now);break;
    case CardId::Almanac:drawAlmanac(now);break;
    case CardId::MinimalClock:drawMinimalClock(now);break;
    case CardId::Overview:drawOverview(now);break;
  }
}
