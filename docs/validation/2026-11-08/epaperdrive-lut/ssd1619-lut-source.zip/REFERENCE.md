# SSD1619 三色局刷实验

2026-11-08：参考 HalfSweetStudio/EPaperDrive（AGPL-3.0）WAVEFORM_SETTING_LUT.h 中的 LUTDefault_part_dke42。
来源：https://github.com/HalfSweetStudio/EPaperDrive

移植70字节波形与3A/3B扫描时序；保留面板屏内电压，使用显式旧/新RAM同步，不依赖其0x37设置。0x22/C7激活，不重新加载OTP覆盖LUT。仅测试96×72秒数窗口，最多6次，之后暂停；时分暂固定。没有OTP编程。此实验不代表已经通过实屏验证。
稳定版本为0.1.8，NVS配置不保存实验模式。
