Reference: HalfSweetStudio/EPaperDrive, AGPL-3.0
https://github.com/HalfSweetStudio/EPaperDrive
227-byte LUTDefault_part_GDEY042Z98 adapted after actual 233-byte readback. Native extra 6 bytes 221741a83250 are NOT overwritten. C0 power on, CF Mode2 update without OTP reload; border HiZ, explicit old/new sync. Temporary bounded seconds test; stable NVS configuration unchanged.
