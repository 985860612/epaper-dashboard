#include "app.h"
#include <WiFi.h>
#include <esp_sntp.h>

#if !defined(CONFIG_IDF_TARGET_ESP32S3)
#error "Select ESP32-S3 with USB CDC enabled"
#endif
SET_LOOP_TASK_STACK_SIZE(32768);

bool needRefresh=true, needFetch=true, needReconnect=false;
bool apActive=false, rendering=false;
uint32_t loopCount=0, screenCheckCount=0, weatherFetchCount=0, stockFetchCount=0;
time_t lastDisplayedEpoch=0;
String displayedView="pending";
int activeStock=0;
uint32_t lastRefreshMs=0;
uint32_t settingsRevision=0,lastFrameElapsedMs=0,fullRefreshCount=0,partialRefreshCount=0;
String lastFrameKind="none",partialStatus="pending";
String weatherError, stockError, displayError;
time_t lastNtpSync=0;
static volatile bool syncNotification=false;
static uint32_t wifiAttempt=0, lastWeatherMs=0, lastStockMs=0, lastRotateMs=0;
static bool wasOnline=false, ntpStarted=false;
static Phase previousPhase=Phase::Unknown;

bool clockReady() { return time(nullptr)>1767225600; }
String dateCompact() {
  time_t epoch=time(nullptr); tm now{}; localtime_r(&epoch,&now);
  char date[9]; strftime(date,sizeof(date),"%Y%m%d",&now); return date;
}
Phase currentPhase() {
  time_t epoch=time(nullptr); tm t{}; localtime_r(&epoch,&t);
  bool day=isTradingDate(t.tm_year+1900,t.tm_mon+1,t.tm_mday,t.tm_wday,cfg.calendarYear,cfg.holidays.c_str());
  return marketPhase(clockReady(),t.tm_year+1900==cfg.calendarYear,day,t.tm_hour*60+t.tm_min);
}
const char* phaseCode(Phase p) {
  switch(p) {
    case Phase::Auction:return "auction";
    case Phase::Opening:return "opening";
    case Phase::Trading:return "trading";
    case Phase::Closing:return "closing_auction";
    case Phase::Unknown:return "calendar_or_clock_unknown";
    default:return "closed";
  }
}

static void startWifi() {
  WiFi.mode(apActive ? WIFI_AP_STA : WIFI_STA);
  WiFi.setAutoReconnect(true);
  if(cfg.ssid.length()) WiFi.begin(cfg.ssid.c_str(),cfg.wifiPassword.c_str());
  wifiAttempt=millis();
}
static void startAP() {
  if(apActive)return;
  WiFi.mode(WIFI_AP_STA);
  String name="EPaper-"+String(static_cast<uint32_t>(ESP.getEfuseMac()),HEX);
  apActive=WiFi.softAP(name.c_str(),cfg.adminPassword.c_str());
  Serial.println(apActive ? "SETUP_AP_READY" : "SETUP_AP_FAILED");
  needRefresh=true;
}

static void serialCommands() {
  static String line;
  while(Serial.available()) {
    char c=Serial.read();
    if(c=='\n') {
      JsonDocument d;
      auto err=deserializeJson(d,line); line="";
      if(err) { Serial.println("{\"event\":\"invalid_command\"}"); continue; }
      String cmd=d["command"].as<String>();
      if(cmd=="provision") {
        String error;
        if(applySettings(d["config"].as<JsonObjectConst>(),error,true)) {
          Serial.println("{\"event\":\"provisioned\"}");
          needReconnect=true;
        } else { JsonDocument response; response["event"]="provision_failed"; response["error"]=error; serializeJson(response,Serial); Serial.println(); }
      } else if(cmd=="status") {
        JsonDocument response;
        response["event"]="status"; response["version"]=VERSION;
        response["ip"]=WiFi.status()==WL_CONNECTED ? WiFi.localIP().toString() : "";
        response["clockReady"]=clockReady(); response["lastNtpSync"]=lastNtpSync;
        response["phase"]=phaseCode(currentPhase()); response["ap"]=apActive;
        response["freeHeap"]=ESP.getFreeHeap();
        response["weatherValid"]=weather.valid; response["weatherError"]=weatherError;
        response["stockValid"]=stock.valid; response["stockError"]=stockError;
        response["stockPoints"]=stock.count; response["quoteStamp"]=stock.stamp;
        response["lastRefreshMs"]=lastRefreshMs; response["displayError"]=displayError;
        serializeJson(response,Serial); Serial.println();
      } else Serial.println("{\"event\":\"unknown_command\"}");
    } else if(c!='\r') {
      if(line.length()<8192) line+=c; else line="";
    }
  }
}

void setup() {
  Serial.begin(115200);
  Serial.setRxBufferSize(8192);
#if ARDUINO_USB_CDC_ON_BOOT
  Serial.setTxTimeoutMs(0);
#endif
  delay(1500);
  Serial.printf("\nSTART %s\n",VERSION);
  setenv("TZ","CST-8",1); tzset();
  loadSettings(); loadWeatherCache();
  startWifi(); setupWeb(); initScreen();
  // Automatic clock sync is handled by the SNTP task, independently of screen refresh.
  esp_sntp_set_time_sync_notification_cb([](struct timeval*) { syncNotification=true; });
}

void loop() {
  ++loopCount;
  serialCommands(); serviceWeb();
  if(needReconnect) {
    needReconnect=false;
    if(apActive) { WiFi.softAPdisconnect(true); apActive=false; }
    WiFi.disconnect(); wasOnline=false; startWifi();
    lastWeatherMs=lastStockMs=0;
  }
  bool online=WiFi.status()==WL_CONNECTED;
  if(online && !wasOnline) {
    Serial.printf("WIFI_CONNECTED ip=%s\n",WiFi.localIP().toString().c_str());
    if(!ntpStarted) {
      configTzTime("CST-8","ntp1.aliyun.com","ntp2.aliyun.com","ntp3.aliyun.com");
      esp_sntp_set_sync_interval(3600000UL); ntpStarted=true;
    } else esp_sntp_restart();
    needFetch=true;
  }
  wasOnline=online;
  if(!online && millis()-wifiAttempt>30000) { startAP(); startWifi(); }
  if(syncNotification) {
    syncNotification=false; lastNtpSync=time(nullptr);
    Serial.printf("NTP_SYNC_OK interval_ms=%lu\n",static_cast<unsigned long>(esp_sntp_get_sync_interval()));
    needFetch=needRefresh=true;
  }
  Phase phase=currentPhase();
  if(phase!=previousPhase) { previousPhase=phase; needRefresh=needFetch=true; }
  bool showStocks=cfg.view=="stock" || (cfg.view=="auto" && stockPage(phase));
  uint32_t now=millis();
  if(showStocks && cfg.stockCount>1 && lastRotateMs && now-lastRotateMs>=static_cast<uint32_t>(cfg.rotationSeconds)*1000) {
    activeStock=(activeStock+1)%cfg.stockCount; stock=Stock(); needFetch=true;
    lastRotateMs=now;
  }
  if(!lastRotateMs) lastRotateMs=now;
  if(online && clockReady()) {
    bool forced=needFetch;
    needFetch=false;
    if(forced || !lastWeatherMs || now-lastWeatherMs>=1800000UL) {
      weatherError="";
      ++weatherFetchCount;
      bool ok=fetchWeather(weatherError);
      lastWeatherMs=now;
      if(!ok) lastWeatherMs=now-1740000UL; // Retry after one minute; preserve valid cache.
      needRefresh=true;
      Serial.printf("WEATHER_FETCH ok=%d free_heap=%u\n",ok,ESP.getFreeHeap());
      serviceWeb();
    }
    if(showStocks && (forced || !lastStockMs || now-lastStockMs>=static_cast<uint32_t>(cfg.refreshSeconds)*1000)) {
      stockError="";
      ++stockFetchCount;
      bool ok=fetchStock(cfg.stocks[activeStock],stockError);
      lastStockMs=now; needRefresh=true;
      Serial.printf("STOCK_FETCH ok=%d points=%d free_heap=%u\n",ok,stock.count,ESP.getFreeHeap());
    }
  }
  // Do not draw the same stale frame before NTP or Wi-Fi has a chance to connect.
  bool ready=online && (clockReady() || millis()>30000);
  static uint32_t lastScreenCheck=0;
  if((ready || apActive) && millis()-lastScreenCheck>=1000) {
    lastScreenCheck=millis(); ++screenCheckCount; refreshScreen();
  }
  delay(2);
}
