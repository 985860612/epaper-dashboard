Reference: HalfSweetStudio/EPaperDrive, AGPL-3.0. Same 227-byte LUT as the user-confirmed working baseline. This experiment sets volatile DCVCOM=08 (-0.2V, per upstream) only during partial updates and restores the actual panel-native value after BUSY. Source/gate voltages and NVS are not changed. No OTP programming.
https://github.com/HalfSweetStudio/EPaperDrive
