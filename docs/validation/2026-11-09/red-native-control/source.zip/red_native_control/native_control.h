#pragma once
#include <cstddef>
#include <cstdint>
#include <cstring>
struct NativeControlInfo { unsigned frames=0;unsigned nominalMilliseconds=0; };
inline bool copyNativeControl(const uint8_t* native,size_t length,uint8_t* output,size_t capacity,NativeControlInfo& info) {
  info={};if(!native || !output || length!=233 || capacity<227 || native==output)return false;
  const uint8_t tail[]={0x22,0x17,0x41,0xa8,0x32,0x50};
  if(std::memcmp(native+227,tail,6) || native[224]!=2 || native[225]!=0 || native[226]!=0)return false;
  unsigned total=0;
  for(unsigned group=0;group<8;++group) {
    const uint8_t* common=native+group*7;
    for(unsigned table=1;table<4;++table) {
      const uint8_t* row=native+table*56+group*7;
      if(row[0]!=common[0] || row[5]!=common[5] || row[6]!=common[6])return false;
      for(unsigned p=1;p<=4;++p)if((row[p]&63)!=(common[p]&63))return false;
    }
    for(unsigned p=1;p<=4;++p) {
      if((common[p]>>6)!=0)return false;
      total+=common[0]*(common[p]&63)*common[p<=2?5:6];
    }
  }
  if(total<900 || total>1100)return false; // <=22 s at native 50 Hz, plus power sequence
  std::memcpy(output,native,227); // no LUTB hold class, no phase deletion or reduction
  info.frames=total;info.nominalMilliseconds=total*1000/50;return true;
}
inline uint8_t nativeWireByte(uint8_t command,uint8_t bw,uint8_t color) {
  return command==0x24 ? bw : static_cast<uint8_t>(~color);
}
