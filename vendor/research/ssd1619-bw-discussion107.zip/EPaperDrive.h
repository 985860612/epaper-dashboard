
#include <Arduino.h>
#include <SPI.h>
#include "GUI_Paint.h"

#define EPD_CS_0 digitalWrite(_CS, LOW)
#define EPD_CS_1 digitalWrite(_CS, HIGH)
#define isEPD_CS digitalRead(_CS)

#define EPD_RST_0 digitalWrite(_RST, LOW)
#define EPD_RST_1 digitalWrite(_RST, HIGH)
#define isEPD_RST digitalRead(_RST)

#define EPD_DC_0 digitalWrite(_DC, LOW)
#define EPD_DC_1 digitalWrite(_DC, HIGH)

#define READ_EPD_BUSY digitalRead(_BUSY)

#define EPD_CLK_0 digitalWrite(_CLK, LOW)
#define EPD_CLK_1 digitalWrite(_CLK, HIGH)

#define EPD_DIN_0 digitalWrite(_DIN, LOW)
#define EPD_DIN_1 digitalWrite(_DIN, HIGH)
/*
 * //设置io口
#define CS 15
#define RST 26
#define DC 27
#define BUSY 25

#define CLK 13
#define DIN 14
EPaperDrive EPD(0, CS, RST, DC, BUSY, CLK, DIN); //驱动库的实例化，此处为使用软件SPI

 EPD.EPD_init_Full();   //全刷的初始化    
 EPD.EPD_init_Part();   //局刷的初始化
 
 EPD.EPD_Dis_Full((uint8_t *)gImage_BW, 1); //全刷显示图片
 EPD.EPD_Dis_Part(x, xx,y, yy, (uint8_t *)gImage_R, 1); //局刷显示图片
  
 EPD.deepsleep();       //休眠

*/

/*
 * 典型使用流程
 * 1.EPD_init_Full/初始化//此
 * 
 * 2.clearbuffer清除缓存图像
 *3
 * 4
 * 5
 * 6.EPD_DisFull/EPD_Dis_Part更新屏幕图像//此
 * 7.deepsleep睡眠//
 *
 * 屏幕有圆点的角为（0，0）点，x方向为垂直方向，y方向为水平方向
 */
class EPaperDrive
{
public:
  // @brief 构造函数，初始化软硬SPI及引脚定义

  EPaperDrive(bool SPIMode, uint8_t CS, uint8_t RST, uint8_t DC, uint8_t BUSY, uint8_t CLK = 127, uint8_t DIN = 127);

 // @brief 构析函数

  ~EPaperDrive();

void EDP_Inverted_Color(bool zhi);//设置反色/0不反色 1反色
  
void EPD_init_Full(void);// @brief 墨水屏全刷的初始化
void EPD_init_Part(void); // @brief 墨水屏局刷的初始化
  
void EPD_init_Part_4gray(void);//局刷4灰度初始化
void EPD_init_Part_16gray(void);//局刷16灰度初始化

  
void EPD_Dis_Full(uint8_t *DisBuffer, uint8_t Label);  // @brief 全刷传入的图像 // Label：1正常2全黑3全白
void EPD_Dis_Part(int xStart, int xEnd, int yStart, int yEnd, uint8_t *DisBuffer, uint8_t Label); // @brief 局刷传入的图像// Label：1正常2全黑3全白


/*  
void EPD_init_Part_4gray_pic(int16_t xMove, int16_t yMove, int16_t width, int16_t height, const uint8_t *xbm);//刷新4灰度图片
void EPD_init_Part_16gray_pic(int16_t xMove, int16_t yMove, int16_t width, int16_t height, const uint8_t *xbm);//刷新16灰度图片
*/
void deepsleep(void); //@brief 让墨水屏进入睡眠模式，节省功耗
////
void DrawXbm_p_4gray(int16_t xMove, int16_t yMove, int16_t width, int16_t height, const uint8_t *xbm, uint8_t level);
  void DrawXbm_p_gray(int16_t xMove, int16_t yMove, int16_t width, int16_t height, const uint8_t *xbm, uint8_t level);//@brief 在图像缓存中画以PROGMEM类型储存的灰度图片
  
  void SetHardSPI(SPIClass *spi);// @brief 设置采用硬件spi的通道（用户请先初始化SPI之后再传入对应SPI的指针）
  void EPD_Transfer_Full_BW(uint8_t *DisBuffer, uint8_t Label); // @brief 直接向RAM中写全刷的黑白图片
  void EPD_Transfer_Part(int xStart, int xEnd, int yStart, int yEnd, uint8_t *DisBuffer, uint8_t Label);  // @brief 直接向RAM中写局刷的图像
  void DrawXbm_P(int16_t xMove, int16_t yMove, int16_t width, int16_t height, const uint8_t *xbm); // @brief 在图像缓存中画以PROGMEM类型储存图片

  void DrawXbm_spiff_gray(int16_t xMove, int16_t yMove, int16_t width, int16_t height, uint8_t level);// @brief 在图像缓存中画以文件系统储存的灰度图片
  void EPD_Set_Contrast(uint8_t vcom); // @brief 设置vcom
  void EPD_Update(void); // @brief 墨水屏全刷更新
  void EPD_Update_Part(void);// @brief 墨水屏局刷更新
  bool ReadBusy(void); //@brief 等待BUSY信号变为空闲（最大200ms超时
  bool ReadBusy_long(void); // @brief 等待BUSY信号变为空闲（最大2000ms超时）
  void EPD_WriteCMD(uint8_t command);// @brief 向墨水屏驱动芯片写入命令
  void EPD_WriteData(uint8_t data); // @brief 向墨水屏驱动芯片写入数据
  void EPD_Write(uint8_t *value, uint8_t datalen);// @brief 向墨水屏驱动芯片中写命令和数据（第一个字节为命令，剩下的均为数据）
    void EPD_WriteDispRam(unsigned int XSize, unsigned int YSize, uint8_t *Dispbuff, unsigned int offset, uint8_t label);
    void EPD_SetRamPointer(uint16_t addrX, uint8_t addrY, uint8_t addrY1);


private:
  uint8_t _CS;
  uint8_t _RST;
  uint8_t _DC;
  uint8_t _BUSY;
  uint8_t _CLK;
  uint8_t _DIN;
  bool _SPIMode;
  bool fanse=0;
  SPIClass *MySPI;

  int xDot=400;
  int yDot=300;

  void SPI_Write(uint8_t value);
  void driver_delay_xms(unsigned long xms);
  void EPD_WirteLUT(uint8_t *LUTvalue, uint8_t Size);
  void EPD_Init(void);
  void EPD_WriteCMD_p1(uint8_t command, uint8_t para);
  void EPD_SetRamArea(uint16_t Xstart, uint16_t Xend, uint8_t Ystart, uint8_t Ystart1, uint8_t Yend, uint8_t Yend1);
};
//局刷lut
  static const uint8_t LUTDefault_part_opm42[] = {
    0x32, // command
    0x00,0x00,0x00,0x00,0x00,0x00,0x00,  //L0 BB R0 B/W 0 
    0x82,0x00,0x00,0x00,0x00,0x00,0x00,  //L1 BW R0 B/W 1
    0x50,0x00,0x00,0x00,0x00,0x00,0x00,  //L2 WB R1 B/W 0
    0x00,0x00,0x00,0x00,0x00,0x00,0x00,  //L3 WW R0 W/W 0
    0x00,0x00,0x00,0x00,0x00,0x00,0x00,  //L4 VCOM
    //b1w1 b2          w2
    0x08,0x08,0x00,0x08,0x01,
    0x00,0x00,0x00,0x00,0x01,
    0x00,0x00,0x00,0x00,0x00,
    0x00,0x00,0x00,0x00,0x00,
    0x00,0x00,0x00,0x00,0x00,
    0x00,0x00,0x00,0x00,0x00,
    0x00,0x00,0x00,0x00,0x00,  
  };
  //全刷lut
  static const uint8_t LUTDefault_full_opm42[] = {
    0x32, // command

    0x08,0x00,0x48,0x40,0x00,0x00,0x00,//L0 B low-high-low-high
    0x20,0x00,0x12,0x20,0x00,0x00,0x00,//L1 W low-high-low
    0x00,0x00,0x00,0x00,0x00,0x00,0x00,
    0x00,0x00,0x00,0x00,0x00,0x00,0x00,
    0x00,0x00,0x00,0x00,0x00,0x00,0x00,//L4 VCOM
    0x05,0x20,0x20,0x05,0x00,
    0x0f,0x00,0x00,0x00,0x00,
    0x20,0x40,0x20,0x20,0x00,
    0x20,0x00,0x00,0x00,0x00,
    0x05,0x00,0x00,0x00,0x01,
    0x00,0x00,0x00,0x00,0x00,
    0x00,0x00,0x00,0x00,0x00, 
    };  


//4灰度刷新lut
  static const uint8_t LUTDefault_part_4gray_opm42[] = {
    0x32, // command

    0x05,0x00,0x10,0x10,0x10,0x00,0x01,//L0 BB R0 B/W 0 
    0x00,0x00,0x00,0x00,0x00,0x00,0x00,   //L1 BW R0 B/W 1
    0x05,0x00,0x05,0x10,0x10,0x00,0x01, //L2 WB R1 B/W 0
    0x00,0x00,0x00,0x00,0x00,0x00,0x00,  //L3 WW R0 W/W 0
    0x00,0x00,0x00,0x00,0x00,0x00,0x00,  //L4 VCOM
    
    0x00,0x00,0x00,0x02,0x01,
    0x00,0x00,0x00,0x00,0x00,
    0x00,0x00,0x00,0x00,0x00,     
    0x00,0x00,0x00,0x00,0x00,
    0x00,0x00,0x00,0x00,0x00,
    0x00,0x00,0x00,0x00,0x00,
    0x00,0x00,0x00,0x00,0x00,  
    };  


//16灰度刷新lut
  static const uint8_t LUTDefault_part_16gray_opm42[] = {
    0x32, // command
 
    0x05,0x00,0x10,0x10,0x10,0x00,0x01,//L0 BB R0 B/W 0 
    0x00,0x00,0x00,0x00,0x00,0x00,0x00,   //L1 BW R0 B/W 1
    0x05,0x00,0x05,0x10,0x10,0x00,0x01, //L2 WB R1 B/W 0
    0x00,0x00,0x00,0x00,0x00,0x00,0x00,  //L3 WW R0 W/W 0
    0x00,0x00,0x00,0x00,0x00,0x00,0x00,  //L4 VCOM

    0x00,0x00,0x00,0x01,0x01,
    0x00,0x00,0x00,0x00,0x00,
    0x00,0x00,0x00,0x00,0x00,     
    0x00,0x00,0x00,0x00,0x00,
    0x00,0x00,0x00,0x00,0x00,
    0x00,0x00,0x00,0x00,0x00,
    0x00,0x00,0x00,0x00,0x00,  
    };  




//2灰度刷新lut


    
