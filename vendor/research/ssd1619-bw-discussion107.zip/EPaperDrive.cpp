#include "EPaperDrive.h"
//#include "EPD_drive_gpio.h"

EPaperDrive::EPaperDrive(bool SPIMode, uint8_t CS, uint8_t RST, uint8_t DC, uint8_t BUSY, uint8_t CLK, uint8_t DIN)
{
    _CS = CS;
    _RST = RST;
    _DC = DC;
    _BUSY = BUSY;
    _CLK = CLK;
    _DIN = DIN;
    _SPIMode = SPIMode;
    if (SPIMode == 0)
    {
        pinMode(CS, OUTPUT); // io初始化
        pinMode(DC, OUTPUT);
        pinMode(RST, OUTPUT);
        digitalWrite(RST, HIGH);
        pinMode(BUSY, INPUT);
        pinMode(CLK, OUTPUT);
        pinMode(DIN, OUTPUT);
    }
    else
    {
        pinMode(CS, OUTPUT);
        pinMode(DC, OUTPUT);
        pinMode(RST, OUTPUT);
        digitalWrite(RST, HIGH);
        pinMode(BUSY, INPUT);
    }
}


EPaperDrive::~EPaperDrive()
{
}
void EPaperDrive::driver_delay_xms(unsigned long xms)
{
    delay(xms);
}


void EPaperDrive::SetHardSPI(SPIClass *spi)
{
    MySPI = spi;
}

void EPaperDrive::SPI_Write(uint8_t value)
{
    if (_SPIMode == 1)
    {
        MySPI->transfer(value);
    }
    else
    {
        EPD_CLK_0;
        // delayMicroseconds(1);
        for (int i = 0; i < 8; i++)
        {
            //高位在前发送方式   
            if ((value & 0x80) == 0x80)
                EPD_DIN_1;
            else
                EPD_DIN_0;
            // delayMicroseconds(1);      //等待数据稳定  根据实际时钟调整
            EPD_CLK_1; //上升沿发送数据
            // delayMicroseconds(1);//CLK高电平保持一段时间 这个可以不需要 根据具体的spi时钟来确定
            EPD_CLK_0;          //把时钟拉低实现为下一次上升沿发送数据做准备
            value = value << 1; //发送数据的位向前移动一位
        }
    }
}







bool EPaperDrive::ReadBusy(void)
{
    unsigned long i = 0;
    for (i = 0; i < 100; i++)
    {
    
      
            if (READ_EPD_BUSY == 0)
            {
               
                return 1;
            }
        
        delay(2);
       
    }
    return 0;
}
bool EPaperDrive::ReadBusy_long(void)
{
    unsigned long i = 0;
    for (i = 0; i < 2000; i++)
    {
        if (READ_EPD_BUSY == 0)
            {
                return 1;   
        }
        delay(2);
    }
    return 0;
}
void EPaperDrive::EPD_WriteCMD(uint8_t command)
{
   
    // ReadBusy();
    EPD_CS_0;
    EPD_DC_0; // command write
    SPI_Write(command);
    EPD_CS_1;
}
void EPaperDrive::EPD_WriteData(uint8_t Data)
{

    EPD_CS_0;
    EPD_DC_1;
    SPI_Write(Data);
    EPD_CS_1;
}

void EPaperDrive::EPD_WriteCMD_p1(uint8_t command, uint8_t para)
{
   
    // ReadBusy();
    EPD_CS_0;
    EPD_DC_0; // command write
    SPI_Write(command);
    EPD_DC_1; // command write
    SPI_Write(para);
    EPD_CS_1;
}

void EPaperDrive::deepsleep(void)
{
  
        ReadBusy_long();
        EPD_WriteCMD_p1(0x10, 0x01);
        // EPD_WriteCMD_p1(0x22,0xc0);//power off
        // EPD_WriteCMD(0x20);

 
}

void EPaperDrive::DrawXbm_p_gray(int16_t xMove, int16_t yMove, int16_t width, int16_t height, const uint8_t *xbm, uint8_t level)
{
    int16_t heightInXbm = (height + 1) / 2;
    uint8_t Data;

//新建图像缓存




    for (int16_t x = 0; x < width; x++)
    {
        for (int16_t y = 0; y < height; y++)
        {
            if (y % 2 != 0)
            {
                Data <<= 4; 
            }
            else
            {
                Data = pgm_read_byte(xbm + (y / 2) + x * heightInXbm);
            }

            if (((Data & 0xf0) >> 4 == level))
            {

 Paint_DrawPoint(yMove + x,xMove + y,  BLACK, DOT_PIXEL_1X1, DOT_STYLE_DFT);

            }
        }
    }
}
//4灰度图片提取
void EPaperDrive::DrawXbm_p_4gray(int16_t xMove, int16_t yMove, int16_t width, int16_t height, const uint8_t *xbm, uint8_t level)
{
    int16_t heightInXbm = (height + 1) / 2;
    uint8_t Data;
unsigned short int shu=0;

int shuju=0x00;

int shu2=0x00;

int i=0;

int zhi=0;
    for (int16_t x = 0; x < width; x++)
    {
        for (int16_t y = 0; y < height; y++)
        {
          
          /*  if (y % 1 != 0)
            {
           shuju=xbm[shu];
           shu=shu+1;
           i=0;
            }*/
if(i>3){
  shuju=xbm[shu];
           shu=shu+1;
           i=0;
}

if(i==0){
zhi=(shuju >> 6);
  
}
if(i==1){
zhi=(shuju & 0x30)>>4;
  
}
if(i==2){
zhi=(shuju & 0x0C)>>2;
  
}



if(i==3){
  zhi=(shuju & 0x03);
  }
            if ( zhi== level)   {
         Paint_DrawPoint(yMove + x,xMove + y,  BLACK, DOT_PIXEL_1X1, DOT_STYLE_DFT);             
            }

 i=i+1;  


 
        }
    }
}
//刷新16灰度图片
/*
void EPaperDrive::EPD_init_Part_16gray_pic(int16_t xMove, int16_t yMove, int16_t width, int16_t height, const uint8_t *xbm){

//新建图像缓存


int hud=0;//灰度层次
EPD_init_Part_16gray(); 
for(int i=0;i<15;i++){
DrawXbm_p_gray(0,0,400,300,(uint8_t *)gImage_400x300maomao,hud);
  EPD_Dis_Part(0, 300,0, 400, (uint8_t *)BlackImage, 1); //将缓存中的图像传给屏幕控制芯片局新屏幕
hud=hud+1;
}

//清除图像缓存
  
}

*/
void EPaperDrive::EPD_Write(uint8_t *value, uint8_t Datalen)
{

    uint8_t i = 0;
    uint8_t *ptemp;
    ptemp = value;

    ReadBusy();

    EPD_CS_0;
    EPD_DC_0;          // When DC is 0, write command
    SPI_Write(*ptemp); // The first uint8_t is written with the command value
    ptemp++;
    EPD_DC_1; // When DC is 1, write Data
    for (i = 0; i < Datalen - 1; i++)
    { // sub the Data
        SPI_Write(*ptemp);
        ptemp++;
    }
    ReadBusy();
    EPD_CS_1;
}
//设置反色/0不反色 1反色
void EPaperDrive::EDP_Inverted_Color(bool zhi){
  
fanse=zhi;
  
  }

void EPaperDrive::EPD_WriteDispRam(unsigned int XSize, unsigned int YSize, uint8_t *Dispbuff, unsigned int offset, uint8_t label)
{

    int i = 0, j = 0;

        ReadBusy();
        EPD_DC_0; // command write
        EPD_CS_0;
        SPI_Write(0x24);
    

    
    EPD_DC_1; // Data write
   

    if (label != 1)
    {
        for (i = 0; i < YSize; i++)
        {
            for (j = 0; j < XSize; j++)
            {
                SPI_Write(label);
            }
        }
    }
    else
    {
        Dispbuff += offset;
        for (i = 0; i < YSize; i++)
        {
            for (j = 0; j < XSize; j++)
            {

              if(fanse == 0){//反色设置             
                SPI_Write(*Dispbuff);
              }else{
                SPI_Write(~*Dispbuff);
              }
                
                Dispbuff++;
            }
            Dispbuff += xDot / 8 - XSize;
        }
    }

    EPD_CS_1;
}

void EPaperDrive::EPD_SetRamArea(uint16_t Xstart, uint16_t Xend,
                                 uint8_t Ystart, uint8_t Ystart1, uint8_t Yend, uint8_t Yend1)
{
   
        uint8_t RamAreaX[3]; // X start and end
        uint8_t RamAreaY[5]; // Y start and end
        RamAreaX[0] = 0x44;  // command
        RamAreaX[1] = Xstart / 8;
        RamAreaX[2] = Xend / 8;
        RamAreaY[0] = 0x45; // command
        RamAreaY[1] = Ystart;
        RamAreaY[2] = Ystart1;
        RamAreaY[3] = Yend;
        RamAreaY[4] = Yend1;
        EPD_Write(RamAreaX, sizeof(RamAreaX));
        EPD_Write(RamAreaY, sizeof(RamAreaY));
        // Serial.printf("set ram area%d %d %d %d %d %d %d %d\n",RamAreaX[0],RamAreaX[1],RamAreaX[2],RamAreaY[0],RamAreaY[1],RamAreaY[2],RamAreaY[3],RamAreaY[4]);
    

            EPD_WriteData(Xstart);
            EPD_WriteData(Xend);
            EPD_WriteData(Ystart);
            EPD_WriteData(Ystart1);
            EPD_WriteData(Yend);
            EPD_WriteData(Yend1);
            EPD_WriteData(0x0);
        
    
}

void EPaperDrive::EPD_SetRamPointer(uint16_t addrX, uint8_t addrY, uint8_t addrY1)
{
    uint8_t RamPointerX[2]; // default (0,0)
    uint8_t RamPointerY[3];
    // Set RAM X address counter
    RamPointerX[0] = 0x4e;
    RamPointerX[1] = addrX;
    // RamPointerX[1] = 0xff;
    // Set RAM Y address counter
    RamPointerY[0] = 0x4f;
    RamPointerY[1] = addrY;
    RamPointerY[2] = addrY1;
    // RamPointerY[1] = 0x2b;
    // RamPointerY[2] = 0x02;

    EPD_Write(RamPointerX, sizeof(RamPointerX));
    EPD_Write(RamPointerY, sizeof(RamPointerY));

    // Serial.printf("0x4e: %d , 0x4f: %d %d \n",RamPointerX[1],RamPointerY[1],RamPointerY[2]);
}

void EPaperDrive::EPD_Init(void)
{
    EPD_RST_0;
    driver_delay_xms(10);
    EPD_RST_1;
    // driver_delay_xms(100);
        EPD_WriteCMD(0x74);  //
        EPD_WriteData(0x54); //
        EPD_WriteCMD(0x7E);  //
        EPD_WriteData(0x3B); //
        
        EPD_WriteCMD(0x01);  //
        EPD_WriteData(0x2B); //
        EPD_WriteData(0x01);
        EPD_WriteData(0x00); //






        EPD_WriteCMD(0x0C);  //
        EPD_WriteData(0x8B); //
        EPD_WriteData(0x9C); //
        EPD_WriteData(0xD6); //
        EPD_WriteData(0x0F); //

        EPD_WriteCMD(0x3A);  //
        EPD_WriteData(0x21); //
        EPD_WriteCMD(0x3B);  //
        EPD_WriteData(0x06); //
        EPD_WriteCMD(0x3C);  //
        EPD_WriteData(0x03); //

        EPD_WriteCMD(0x11);  // data enter mode
        EPD_WriteData(0x01); // 01 –Y decrement, X increment,

        EPD_WriteCMD(0x2C);  //
        EPD_WriteData(0x00); // fff

        EPD_WriteCMD(0x37);  //
        EPD_WriteData(0x00); //
        EPD_WriteData(0x00); //
        EPD_WriteData(0x00); //
        EPD_WriteData(0x00); //
        EPD_WriteData(0x80); //

        EPD_WriteCMD(0x21);  //
        EPD_WriteData(0x40); //
        EPD_WriteCMD(0x22);
        EPD_WriteData(0xc7); // c5forgraymode//
}
void EPaperDrive::EPD_Set_Contrast(uint8_t vcom)
{
        EPD_WriteCMD(0x2C);  //
        EPD_WriteData(vcom); // fff  
}

void EPaperDrive::EPD_Update(void)
{
        EPD_WriteCMD(0x20);
}
void EPaperDrive::EPD_Update_Part(void)
{ 
        EPD_WriteCMD(0x20);
}

void EPaperDrive::EPD_init_Full(void)
{
    EPD_Init();

        EPD_Write((uint8_t *)LUTDefault_full_opm42, sizeof(LUTDefault_full_opm42));
}
void EPaperDrive::EPD_init_Part(void)
{  
        EPD_Init();
        EPD_WriteCMD(0x21);
        EPD_WriteData(0x00);
        EPD_Write((uint8_t *)LUTDefault_part_opm42, sizeof(LUTDefault_part_opm42));  
}



void EPaperDrive::EPD_Dis_Full(uint8_t *DisBuffer, uint8_t Label)
{
    int nowtime = millis();
  
        unsigned int yStart = 0;
        unsigned int yEnd = yDot - 1;
        unsigned int xStart = 0;
        unsigned int xEnd = xDot - 1;
        unsigned long temp = yStart;

        yStart = yDot - 1 - yEnd;
        yEnd = yDot - 1 - temp;

        EPD_SetRamPointer(xStart / 8, yEnd % 256, yEnd / 256);
        EPD_SetRamArea(xStart, xEnd, yEnd % 256, yEnd / 256, yStart % 256, yStart / 256);

      

        if (Label == 2)
        {
          
            EPD_WriteDispRam(xDot / 8, yDot, (uint8_t *)DisBuffer, 0, 0x00); // white
        }
        else if (Label == 3)
        {
      
            EPD_WriteDispRam(xDot / 8, yDot, (uint8_t *)DisBuffer, 0, 0xff); // black
        }
        else
        {
            EPD_WriteDispRam(xDot / 8, yDot, (uint8_t *)DisBuffer, 0, 1);
        }
        nowtime = millis() - nowtime;
        EPD_Update();
        nowtime = millis() - nowtime;

        int updatatime = nowtime;
        // Serial.printf("开始全刷 \n");
        ReadBusy_long();
        ReadBusy_long();
        ReadBusy_long();
        ReadBusy_long();
        nowtime = millis() - nowtime;
        // Serial.printf("全刷结束，耗时%dms", nowtime - updatatime);
        
            EPD_SetRamPointer(xStart / 8, yEnd % 256, yEnd / 256);
            EPD_WriteDispRam(xDot / 8, yDot, (uint8_t *)DisBuffer, 0, 1);
        
    }
    
  //局刷4灰度初始化
  void EPaperDrive::EPD_init_Part_4gray(void){
    
        //EPD_Init();
        /////初始化设置
 EPD_RST_0;
    driver_delay_xms(10);
    EPD_RST_1;
    // driver_delay_xms(100);
        EPD_WriteCMD(0x74);  //
        EPD_WriteData(0x54); //
        EPD_WriteCMD(0x7E);  //
        EPD_WriteData(0x3B); //
        
        EPD_WriteCMD(0x01);  //
        EPD_WriteData(0x2B); //
        EPD_WriteData(0x01);
        EPD_WriteData(0x00); //

        EPD_WriteCMD(0x0C);  //
        EPD_WriteData(0x8B); //
        EPD_WriteData(0x9C); //
        EPD_WriteData(0xD6); //
        EPD_WriteData(0x0F); //

        EPD_WriteCMD(0x3A);  ////频率设置120
        EPD_WriteData(0x14); //
        EPD_WriteCMD(0x3B);  //
        EPD_WriteData(0x05); //
        EPD_WriteCMD(0x3C);  //
        EPD_WriteData(0x03); //

        EPD_WriteCMD(0x11);  // data enter mode
        EPD_WriteData(0x01); // 01 –Y decrement, X increment,

        EPD_WriteCMD(0x2C);  //
        EPD_WriteData(0x00); // fff

        EPD_WriteCMD(0x37);  //
        EPD_WriteData(0x00); //
        EPD_WriteData(0x00); //
        EPD_WriteData(0x00); //
        EPD_WriteData(0x00); //
        EPD_WriteData(0x80); //

        EPD_WriteCMD(0x21);  //
        EPD_WriteData(0x40); //
        EPD_WriteCMD(0x22);
        EPD_WriteData(0xc7); // c5forgraymode//
        /////初始位设置完毕
        EPD_WriteCMD(0x21);
        EPD_WriteData(0x00);
        EPD_Write((uint8_t *)LUTDefault_part_4gray_opm42, sizeof(LUTDefault_part_4gray_opm42));
  }
void EPaperDrive::EPD_init_Part_16gray(void){
    
        //EPD_Init();
        /////初始化设置
 EPD_RST_0;
    driver_delay_xms(10);
    EPD_RST_1;
    // driver_delay_xms(100);
        EPD_WriteCMD(0x74);  //
        EPD_WriteData(0x54); //
        EPD_WriteCMD(0x7E);  //
        EPD_WriteData(0x3B); //
        
        EPD_WriteCMD(0x01);  //
        EPD_WriteData(0x2B); //
        EPD_WriteData(0x01);
        EPD_WriteData(0x00); //

        EPD_WriteCMD(0x0C);  //
        EPD_WriteData(0x8B); //
        EPD_WriteData(0x9C); //
        EPD_WriteData(0xD6); //
        EPD_WriteData(0x0F); //

        EPD_WriteCMD(0x3A);  ////频率设置
        EPD_WriteData(0x09); //
        EPD_WriteCMD(0x3B);  //
        EPD_WriteData(0x03); //
        EPD_WriteCMD(0x3C);  //
        EPD_WriteData(0x03); //

        EPD_WriteCMD(0x11);  // data enter mode
        EPD_WriteData(0x01); // 01 –Y decrement, X increment,

        EPD_WriteCMD(0x2C);  //
        EPD_WriteData(0x00); // fff

        EPD_WriteCMD(0x37);  //
        EPD_WriteData(0x00); //
        EPD_WriteData(0x00); //
        EPD_WriteData(0x00); //
        EPD_WriteData(0x00); //
        EPD_WriteData(0x80); //

        EPD_WriteCMD(0x21);  //
        EPD_WriteData(0x40); //
        EPD_WriteCMD(0x22);
        EPD_WriteData(0xc7); // c5forgraymode//
        /////初始位设置完毕
        EPD_WriteCMD(0x21);
        EPD_WriteData(0x00);
        EPD_Write((uint8_t *)LUTDefault_part_16gray_opm42, sizeof(LUTDefault_part_16gray_opm42));
  }
void EPaperDrive::EPD_Dis_Part(int xStart, int xEnd, int yStart, int yEnd, uint8_t *DisBuffer, uint8_t Label)
{
   
   
        int temp1 = xStart, temp2 = xEnd;
        xStart = yStart;
        xEnd = yEnd;
        yEnd = yDot - temp1 - 2;
        yStart = yDot - temp2 - 3;
    
    unsigned int Xsize = xEnd - xStart;
    unsigned int Ysize = yEnd - yStart + 1;
    if (Xsize % 8 != 0)
    {
        Xsize = Xsize + (8 - Xsize % 8);
    }
    Xsize = Xsize / 8;
    unsigned int offset = yStart * xDot / 8 + xStart / 8;
 
        unsigned long temp = yStart;
        yStart = yDot - 1 - yEnd;
        yEnd = yDot - 1 - temp;

        EPD_SetRamArea(xStart, xEnd, yEnd % 256, yEnd / 256, yStart % 256, yStart / 256);
        EPD_SetRamPointer(xStart / 8, yEnd % 256, yEnd / 256);
        if (Label == 2)
            EPD_WriteDispRam(xEnd - xStart, yEnd - yStart + 1, (uint8_t *)DisBuffer, offset, 0x00);
        else if (Label == 3)
            EPD_WriteDispRam(xEnd - xStart, yEnd - yStart + 1, (uint8_t *)DisBuffer, offset, 0xff);
        else
            EPD_WriteDispRam(Xsize, Ysize, (uint8_t *)DisBuffer, offset, 1);

        EPD_Update_Part();
        ReadBusy_long();
        ReadBusy_long();
     
      
       
            EPD_WriteDispRam(Xsize, Ysize, (uint8_t *)DisBuffer, offset, 1);
       

        // EPD_WriteDispRam_Old(Xsize, Ysize,(uint8_t *)DisBuffer,offset,1);
    

   
}
